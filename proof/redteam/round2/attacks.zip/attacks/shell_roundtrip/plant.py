"""shell_roundtrip: undisclosed outside financing routed through a nominee-run, backdated affiliate (see README.md)."""
import random
import bookio
from common import borrower_info, max_suffix

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance", "receivables_finance"]
START_MONTH = 6
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = True      # the affiliate is added with formed_month < 0 and has_operations = True

TARGET_FRACTION = 0.16
N_PAYMENTS = 8
FIRST = ["Harbor", "Cedar", "Vista", "Orchard", "Granite", "Summit", "Lantern", "Meadow"]
SECOND = ["Receivables Services", "Collections Partners", "Trade Settlement", "Commercial Services"]


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    rng = random.Random(seed)
    b, w = borrower_info(book_dir, borrower_id)
    limit = b["facility_limit"]

    persons = bookio.load(book_dir, "persons")
    nominee_id = f"P{max_suffix(['-' + p['person_id'][1:] for p in persons]) + 1:05d}"
    persons.append({"person_id": nominee_id, "name": "Alan Whitfield"})        # a nominee, unrelated to the owner on paper
    bookio.save(book_dir, "persons", persons)

    entities = bookio.load(book_dir, "entities")
    agents = sorted({e["registered_agent"] for e in entities if e["registered_agent"].startswith("(synthetic)")})
    num = max(int(e["entity_id"][1:]) for e in entities if e["entity_id"][1:].isdigit()) + 1
    affiliate_id = f"E{num:06d}"
    name = f"{rng.choice(FIRST)} {rng.choice(SECOND)} LLC"
    entities.append({
        "entity_id": affiliate_id, "name": name, "kind": "company", "officer_person_id": nominee_id,
        "address": f"{rng.randint(100, 9999)} Commerce St, Suite {rng.randint(100, 999)}", "state": rng.choice(["DE", "WY", "NV"]),
        "formed_month": -rng.randint(60, 120), "has_operations": True,
        "phone": f"555-{rng.randint(100, 999)}-{rng.randint(1000, 9999)}", "registered_agent": rng.choice(agents),
    })
    bookio.save(book_dir, "entities", entities)

    payments = bookio.load(book_dir, "payments")
    acct = next((p["account_id"] for p in payments if p["borrower_id"] == borrower_id), f"{w['facility_id']}-COLL")
    nxt = max(int(p["txn_id"][1:]) for p in payments) + 1
    months = sorted(rng.sample(range(START_MONTH, 24), N_PAYMENTS))
    each = TARGET_FRACTION * limit / N_PAYMENTS
    rows = [{"txn_id": f"T{nxt + i:09d}", "month": m, "day": rng.randint(1, 27), "borrower_id": borrower_id, "account_id": acct,
             "payer_id": affiliate_id, "payer_name": name, "amount": round(each * rng.uniform(0.9, 1.1), 2),
             "memo": "receivable settlement", "ref": ""} for i, m in enumerate(months)]
    payments.extend(rows)
    bookio.save(book_dir, "payments", payments)
    total = sum(r["amount"] for r in rows)
    return {"gain_usd": float(total),
            "how": f"{N_PAYMENTS} payments totalling ${total:,.0f} of undisclosed outside borrowing routed in through a backdated, nominee-officered affiliate {affiliate_id}"}
