# deferment_mask

**Story.** The borrower announces a hardship deferment programme and files a
disclosure for it. From month 9 onward, every loan that is too far behind to
count as collateral is flagged as deferred and asserted to be eligible anyway,
on the argument that a loan whose payments are formally paused is not really
past due. Loans that had already been charged off and had dropped off the tape
are put back on it under the same story at their last known balance. A cohort of
new loans is written that is delinquent from the first month and deferred from
the first month, never amortises, and is carried as good collateral throughout.

The important restraint is what the borrower does not do. It never misstates how
late a loan is. `dpd_bucket_reported` is left honest, and the servicer record is
left honest too, including for the new cohort, which is booked truthfully as
sliding from current to ninety-plus days down. The lie is confined to one
column: `eligible_reported`.

**Allegation it follows.** Tricolor, closely. On a recorded call on 17 August
2025 Chu "proposed blaming certain loan data discrepancies on fictitious
deferment policies", and said the problem would only come "if they sent an
auditor and they said, pull this up on your screen". This attack is built so
that pulling it up on screen shows exactly what the tape shows.

**Levers.** The loan tape. Disclosures. The servicer system, but only to book
the new cohort honestly - the trick itself needs no servicer access and the
flipping of existing rows uses none.

**Gain.** The balance at month 23 of collateral asserted eligible while reported
ninety or sixty days down, multiplied by the advance rate. Roughly 6.5% of
`facility_limit`.

**Why monitoring would miss it.** Every comparison between two tables agrees.
Tape ties to servicer on both balance and delinquency, for every row, including
the planted ones. There is no payment that fails to reconcile, because deferred
loans are not expected to pay. The programme is disclosed, and seven of the
thirty-four honest borrowers in the sample book disclose deferment programmes of
their own, so having one is unremarkable.

Catching it requires the monitoring to hold an opinion about eligibility rather
than about consistency - to apply the credit agreement's own test to the
reported delinquency bucket and disagree with the borrower's conclusion. A
checker built around reconciliation rather than around the eligibility
definition will pass this book. The secondary tell is behavioural: deferred
balances that never amortise and never cure, and a deferred share that climbs
without the economic conditions that would explain it.
