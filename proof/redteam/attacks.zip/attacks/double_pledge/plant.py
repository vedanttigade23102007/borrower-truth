"""double_pledge - the same collateral financed twice.

Follows the central Tricolor allegation ("double-pledge collateral to multiple
lenders") and the First Brands allegation that assets "purported to be
unencumbered ... in fact [were] already subject to liens by, or otherwise
pledged to, First Brands' senior lenders".

The borrower raises a second facility from another lender against loans already
pledged to the bank. Three things make it quiet:

  * it stops being enrolled in the shared collateral registry, which the rules
    allow by removing its own rows. Fifteen of the thirty-four honest borrowers
    in the sample book are not enrolled either, so not being there is ordinary;
  * the second lender is never named in a disclosure, and the quarterly debt
    figure is left on its honest trend;
  * interest on the hidden facility leaves the operating account dressed as
    ordinary vendor payments to a freshly formed servicing company, instead of
    as debt service to a lender.

Nothing is added to the tape and nothing is touched in the servicer. The money
is the fraud, not the collateral record.
"""
import bookio
import common

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance",
              "receivables_finance"]
START_MONTH = 8
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = False   # the conduit is a new shell with no operations


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    ctx = common.Ctx(book_dir, borrower_id, seed)
    rng = ctx.rng

    entities = bookio.load(book_dir, "entities")
    persons = bookio.load(book_dir, "persons")
    pledge = bookio.load(book_dir, "pledgecheck")
    outflows = bookio.load(book_dir, "outflows")

    # Pick a lender already in the registry that is not the bank.
    others = [e for e in entities if e["kind"] == "lender" and e["entity_id"] != "E_WF"]
    lender = rng.choice(others) if others else None

    # A new conduit company: formed this year, no operations, nominee officer.
    mint_e = common.entity_minter(entities)
    mint_p = common.person_minter(persons)
    nominee_id = mint_p()
    nominee = common.person_name(rng)
    persons.append({"person_id": nominee_id, "name": nominee})
    conduit_id = mint_e()
    conduit_name = common.company_name(rng)
    entities.append(common.new_entity(
        rng, conduit_id, conduit_name, "company", nominee_id, ctx.state,
        formed_month=max(0, START_MONTH - 3), has_operations=False))

    # Stop being enrolled in the shared collateral registry from START_MONTH.
    dropped = sum(1 for p in pledge if p["borrower_id"] == ctx.bid and p["month"] >= START_MONTH)
    pledge = [p for p in pledge
              if not (p["borrower_id"] == ctx.bid and p["month"] >= START_MONTH)]

    # Draw the hidden facility down in tranches.
    months = common.ramp(START_MONTH, common.LAST_MONTH - 1)
    total = ctx.target()
    tranches = max(3, min(8, len(months) // 2))
    picks = sorted(rng.sample(months, min(tranches, len(months))))
    weights = [common.smooth_share(i, len(picks)) + 0.4 for i in range(len(picks))]
    scale = total / sum(weights)
    draws = [(m, w * scale) for m, w in zip(picks, weights)]

    # Interest leaves the operating account as a vendor payment to the conduit.
    mint_o = common.txn_minter(book_dir, "outflows")
    rate = 0.14 / 12.0
    new_out = []
    outstanding = 0.0
    schedule = dict(draws)
    for m in range(START_MONTH, common.MONTHS):
        outstanding += schedule.get(m, 0.0)
        if outstanding <= 0:
            continue
        svc = outstanding * rate * rng.uniform(0.96, 1.04)
        new_out.append(common.outflow_row(
            ctx, mint_o(), m, rng.randint(3, 26), conduit_id, conduit_name,
            svc, "vendor payment"))

    bookio.save(book_dir, "entities", entities)
    bookio.save(book_dir, "persons", persons)
    bookio.save(book_dir, "pledgecheck", pledge)
    common.save(book_dir, "outflows", outflows + new_out)

    gain = sum(a for _, a in draws)
    lender_name = lender["name"] if lender else "an undisclosed lender"
    return {
        "gain_usd": round(gain, 2),
        "how": (f"${gain:,.0f} raised from {lender_name} against collateral already "
                f"pledged to the bank; {dropped} registry rows removed; interest "
                f"routed through {conduit_name}"),
    }
