"""ghost_invoices: invoices for sales that never happened, to real customers (see README.md)."""
import random
import bookio
from common import borrower_info, max_suffix

APPLIES_TO = ["receivables_finance"]
START_MONTH = 3
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = False

TARGET_FRACTION = 0.14
ROLL_EVERY = 2          # a new batch of ghosts every 2 months
AGE_OUT_DAYS = 90       # my assumption: a ghost stops earning an advance 90 days after its due date


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    rng = random.Random(seed)
    b, w = borrower_info(book_dir, borrower_id)
    limit, adv, facility_id = b["facility_limit"], w["advance_rate"], w["facility_id"]

    invoices = bookio.load(book_dir, "invoices")
    mine = [r for r in invoices if r["borrower_id"] == borrower_id]
    if not mine:
        raise ValueError("no invoices for this borrower")
    debtors = sorted({(r["debtor_id"], r["debtor_name"]) for r in mine})
    goods = sorted({r["description"].split(" units ", 1)[-1] for r in mine})
    avg = sum(r["amount"] for r in mine) / len(mine)
    num_seq = max_suffix([r["invoice_number"] for r in mine]) + 1
    inv_seq = max_suffix([r["invoice_id"].replace("INV", "INV-") for r in invoices]) + 1

    target_face = TARGET_FRACTION * limit / adv       # most fake face value outstanding at once
    batch_months = list(range(START_MONTH, 24, ROLL_EVERY))
    n_per_batch = max(3, round(target_face / 3 / avg))
    ghosts = []
    for m in batch_months:
        for _ in range(n_per_batch):
            ghosts.append({"m": m, "day": rng.randint(1, 27), "due": rng.choice([30, 45, 60]), "w": rng.uniform(0.8, 1.2)})

    def outstanding(month):
        # days measured as month*30 + day, as in the book
        return sum(g["w"] for g in ghosts if g["m"] <= month and (month * 30 + 15) <= g["m"] * 30 + g["day"] + g["due"] + AGE_OUT_DAYS)
    peak_w = max(outstanding(m) for m in range(24))
    scale = target_face / peak_w

    new_rows = []
    for i, g in enumerate(ghosts):
        debtor_id, debtor_name = rng.choice(debtors)
        new_rows.append({
            "borrower_id": borrower_id, "invoice_id": f"INV{inv_seq + i:08d}", "facility_id": facility_id,
            "pledged_month": g["m"], "invoice_number": f"{borrower_id}-{num_seq + i}", "po_number": f"PO{rng.randint(100000, 999999)}",
            "debtor_id": debtor_id, "debtor_name": debtor_name, "issue_month": g["m"], "issue_day": g["day"], "due_days": g["due"],
            "amount": round(g["w"] * scale, 2), "description": f"{rng.randint(50, 900)} units {rng.choice(goods)}",
        })
    invoices.extend(new_rows)
    bookio.save(book_dir, "invoices", invoices)
    return {"gain_usd": float(adv * target_face),
            "how": f"{len(new_rows)} invoices for sales that never happened, pledged in batches every {ROLL_EVERY} months to real customers; "
                   f"peak fake face value ${target_face:,.0f} still within 90 days of due; gain = advance rate x that peak"}
