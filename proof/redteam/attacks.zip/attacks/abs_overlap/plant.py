"""abs_overlap - sold to investors and pledged to the bank at the same time.

Follows the SEC's Tricolor allegation: the company "represented that the loans
included in the ABS collateral pools were free and clear of any other liens when
the defendants knew that many had been or would soon be double pledged".

The loans here are real. They were originated, they are in the servicer, they
pay. They have simply been sold into the borrower's own public securitization
and pledged to the bank as well, so two sets of money are advanced against one
set of cars.

What makes it hold up is a gap in the reporting. The ABS-EE report carries no
vehicle identifier, so there is no key to join on. A reader has to match on
origination month, amount, rate, term, make, model, model year, obligor state
and credit score - and the borrower perturbs the reported amount and score a
little in the investor report, the way a servicing-system export legitimately
might, so an exact nine-column match misses.
"""
import bookio
import common

APPLIES_TO = ["auto_finance"]
START_MONTH = 6
USES_SERVICER_RECORDS = True   # the loans are real and must exist in the servicer
USES_COMPANY_HISTORY = False


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    ctx = common.Ctx(book_dir, borrower_id, seed)
    rng = ctx.rng

    tape = bookio.load(book_dir, "tape")
    truth = bookio.load(book_dir, "source_truth")
    payments = bookio.load(book_dir, "payments")
    abs_rows = bookio.load(book_dir, "public_abs")

    prof = common.loan_profile(ctx, tape)
    if not prof["sample"]:
        return {"gain_usd": 0.0, "how": "borrower has no loan tape"}

    pool_id = f"SYN-ABS-{ctx.bid}"
    existing_pool = [a for a in abs_rows if a["pool_id"] == pool_id]
    n0 = 0
    if existing_pool:
        tails = [int(a["pool_loan_id"].rsplit("-", 1)[1]) for a in existing_pool]
        n0 = max(tails) + 1

    mint_asset = common.asset_minter(ctx, tape)
    mint_txn = common.txn_minter(book_dir, "payments")

    months = common.ramp(START_MONTH, common.LAST_MONTH - 2)
    need = ctx.target() / ctx.advance_rate

    loans = []
    standing = 0.0
    guard = 0
    while standing < need and guard < 20000:
        guard += 1
        om = rng.choice(months)
        loan = common.draw_loan(ctx, prof, om)
        bal23 = common.balance_at(loan, common.LAST_MONTH)
        if not bal23:
            continue
        aid, oid = mint_asset()
        loans.append((aid, oid, loan, common.person_name(rng)))
        standing += bal23

    new_tape, new_truth, new_pay, new_abs = [], [], [], []
    for k, (aid, oid, loan, who) in enumerate(loans):
        pmt = common.monthly_payment(loan)
        for m in range(loan["orig_month"], common.MONTHS):
            bal = common.balance_at(loan, m)
            if bal is None or bal <= 0:
                break
            new_tape.append(common.tape_row(ctx, aid, oid, loan, m, bal))
            new_truth.append(common.truth_row(ctx, aid, m, 0, bal))
            if m > loan["orig_month"]:
                new_pay.append(common.payment_row(
                    ctx, mint_txn(), m, rng.randint(2, 27), oid, who,
                    pmt * rng.uniform(0.97, 1.03), "loan payment", aid))
            # The same loan, reported to investors, with no VIN and with the
            # amount and score nudged so an exact match on the other columns fails.
            new_abs.append({
                "pool_id": pool_id,
                "issuer_borrower_id": ctx.bid,
                "month": int(m),
                "pool_loan_id": f"{pool_id}-{n0 + k:06d}",
                "orig_month": int(loan["orig_month"]),
                "orig_amount": round(float(loan["orig_amount"]) * rng.uniform(0.985, 1.015), 2),
                "rate": loan["rate"],
                "term": int(loan["term"]),
                "make": loan["make"],
                "model": loan["model"],
                "model_year": int(loan["model_year"]),
                "obligor_state": loan["obligor_state"],
                "credit_score": int(loan["credit_score"]) + rng.choice([-2, -1, 1, 2]),
                "dpd_bucket": 0,
            })

    common.save(book_dir, "tape", tape + new_tape)
    common.save(book_dir, "source_truth", truth + new_truth)
    common.save(book_dir, "payments", payments + new_pay)
    bookio.save(book_dir, "public_abs", abs_rows + new_abs)

    final = sum(r["balance"] for r in new_tape if r["month"] == common.LAST_MONTH)
    gain = final * ctx.advance_rate
    return {
        "gain_usd": round(gain, 2),
        "how": (f"{len(loans)} loans sold into {pool_id} and pledged to the bank; "
                f"${final:,.0f} standing at month 23, advanced at {ctx.advance_rate:.0%}"),
    }
