"""shadow_repledge: real loans pledged a second time under new asset ids (see README.md)."""
import random
import bookio
from common import borrower_info, max_suffix, fake_vin

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance"]
START_MONTH = 2
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = False

TARGET_FRACTION = 0.17


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    rng = random.Random(seed)
    b, w = borrower_info(book_dir, borrower_id)
    limit, adv = b["facility_limit"], w["advance_rate"]

    tape = bookio.load(book_dir, "tape")
    mine = [r for r in tape if r["borrower_id"] == borrower_id]
    if not mine:
        raise ValueError("no tape rows for this borrower")
    # loans on the tape at START_MONTH that stay on the tape to the end and are eligible then
    last_month = {}
    for r in mine:
        last_month[r["asset_id"]] = max(last_month.get(r["asset_id"], -1), r["month"])
    cands = [r for r in mine if r["month"] == START_MONTH and r["eligible_reported"] and last_month[r["asset_id"]] == 23]
    if not cands:
        cands = [r for r in mine if r["month"] == START_MONTH and r["eligible_reported"]]
    rng.shuffle(cands)
    target_balance = TARGET_FRACTION * limit / adv
    chosen, running = [], 0.0
    for r in cands:
        if running >= target_balance:
            break
        chosen.append(r["asset_id"]); running += r["balance"]
    chosen = set(chosen)

    seq = max_suffix([r["asset_id"] for r in mine]) + 1
    new_id = {}
    for a in sorted(chosen):
        new_id[a] = f"A-{borrower_id}-{seq:06d}"; seq += 1
    vin = {a: fake_vin(rng) for a in new_id}

    new_rows, start_bal = [], 0.0
    for r in mine:
        if r["asset_id"] in chosen and r["month"] >= START_MONTH:
            c = dict(r)
            c["asset_id"] = new_id[r["asset_id"]]
            c["vin"] = vin[r["asset_id"]]
            new_rows.append(c)
            if r["month"] == START_MONTH:
                start_bal += r["balance"]
    tape.extend(new_rows)
    bookio.save(book_dir, "tape", tape)
    return {"gain_usd": float(adv * start_bal),
            "how": f"{len(chosen)} real loans (${start_bal:,.0f} at month {START_MONTH}) pledged twice under new asset ids and new VINs; "
                   f"gain = advance rate x duplicated balance"}
