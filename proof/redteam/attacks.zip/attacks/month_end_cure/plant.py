"""month_end_cure - the borrower makes its customers' payments for them.

Not from the allegations. The idea is that nothing in the loan record has to be
false at all. A loan that is sixty days down becomes ineligible; a loan that is
current does not. So shortly before each reporting date the borrower posts the
smallest payment that will roll a delinquent loan back to current, out of its
own pocket, through a payment processor so the money appears to arrive from the
customer.

Every record is then true. The payment really was received, the servicer really
does show the loan current, the tape really does agree with the servicer, and
the loan really does satisfy the eligibility test. What is false is the implied
fact that the customer paid, and the collateral is worth far less than a current
book suggests. The borrower also carries a cohort of loans that never pays and
is cured this way every single month.

The tell is behavioural rather than contradictory: payments bunched into the
last days of the month, sized to the minimum that moves a bucket, on obligors
who are otherwise silent, matched by processor outflows of a similar size.
"""
import bookio
import common

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance"]
START_MONTH = 10
USES_SERVICER_RECORDS = True   # the cure is real and really posts
USES_COMPANY_HISTORY = False


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    ctx = common.Ctx(book_dir, borrower_id, seed)
    rng = ctx.rng

    tape = bookio.load(book_dir, "tape")
    truth = bookio.load(book_dir, "source_truth")
    payments = bookio.load(book_dir, "payments")
    outflows = bookio.load(book_dir, "outflows")

    prof = common.loan_profile(ctx, tape)
    if not prof["sample"]:
        return {"gain_usd": 0.0, "how": "borrower has no loan tape"}

    mint_t = common.txn_minter(book_dir, "payments")
    mint_o = common.txn_minter(book_dir, "outflows")
    mint_asset = common.asset_minter(ctx, tape)

    processor = "PROCESSOR"
    processor_name = "(synthetic) Remittance Processing Services LLC"

    cash_spent = 0.0
    cured = 0
    cured_bal_23 = 0.0   # balance eligible at month 23 only because it was cured
    new_pay, new_out = [], []

    # (a) cure the borrower's genuinely delinquent loans.
    truth_ix = {(r["month"], r["asset_id"]): r for r in truth if r["borrower_id"] == ctx.bid}
    for r in tape:
        if r["borrower_id"] != ctx.bid or r["month"] < START_MONTH:
            continue
        if r["dpd_bucket_reported"] < 1:
            continue
        loan = {"orig_amount": r["orig_amount"], "term": r["term"]}
        step = common.monthly_payment(loan) * r["dpd_bucket_reported"]
        day = rng.randint(24, 28)
        new_pay.append(common.payment_row(
            ctx, mint_t(), r["month"], day, r["obligor_id"], "", step,
            "loan payment", r["asset_id"]))
        cash_spent += step
        cured += 1
        if r["month"] == common.LAST_MONTH and r["dpd_bucket_reported"] >= 2:
            cured_bal_23 += r["balance"]
        r["dpd_bucket_reported"] = 0
        r["eligible_reported"] = True
        t = truth_ix.get((r["month"], r["asset_id"]))
        if t is not None:
            t["dpd_bucket_true"] = 0

    # (b) a cohort that never pays, cured every month so it never ages.
    months = common.ramp(START_MONTH, common.LAST_MONTH - 1)
    need = (ctx.target(0.078) + cash_spent) / ctx.advance_rate
    have = cured_bal_23
    new_tape, new_truth = [], []
    cohort = 0
    guard = 0
    while have < need and guard < 20000:
        guard += 1
        om = rng.choice(months)
        loan = common.draw_loan(ctx, prof, om)
        aid, oid = mint_asset()
        who = common.person_name(rng)
        pmt = common.monthly_payment(loan)
        cohort += 1
        bal = float(loan["orig_amount"])
        for m in range(om, common.MONTHS):
            new_tape.append(common.tape_row(ctx, aid, oid, loan, m, bal))
            new_truth.append(common.truth_row(ctx, aid, m, 0, bal))
            if m > om:
                new_pay.append(common.payment_row(
                    ctx, mint_t(), m, rng.randint(23, 28), oid, who, pmt,
                    "loan payment", aid))
                cash_spent += pmt
                bal = max(0.0, bal - pmt)
        have += bal

    # The cash the borrower fed in has to leave the operating account.
    by_month = {}
    for p in new_pay:
        by_month[p["month"]] = by_month.get(p["month"], 0.0) + p["amount"]
    for m, amt in sorted(by_month.items()):
        new_out.append(common.outflow_row(
            ctx, mint_o(), m, rng.randint(18, 24), processor, processor_name,
            amt * rng.uniform(1.00, 1.02), "vendor payment"))

    common.save(book_dir, "tape", tape + new_tape)
    common.save(book_dir, "source_truth", truth + new_truth)
    common.save(book_dir, "payments", payments + new_pay)
    common.save(book_dir, "outflows", outflows + new_out)

    planted_23 = sum(r["balance"] for r in new_tape if r["month"] == common.LAST_MONTH)
    kept = cured_bal_23 + planted_23
    gain = max(0.0, kept * ctx.advance_rate - cash_spent)
    return {
        "gain_usd": round(gain, 2),
        "how": (f"{cured} delinquent rows cured with token payments plus a "
                f"{cohort}-loan cohort cured monthly; ${kept:,.0f} eligible at "
                f"month 23 against ${cash_spent:,.0f} of own cash fed in"),
    }
