"""deferment_mask - a deferment programme invented to make bad loans eligible.

Follows the Tricolor allegation directly: on a recorded call Chu "proposed
blaming certain loan data discrepancies on fictitious deferment policies", and
worried only about an auditor pulling a loan up on screen.

The borrower never lies about how late a loan is. `dpd_bucket_reported` stays
honest and the servicer record stays honest, so a tape-to-servicer tie-out finds
nothing. The lie is one column over: every delinquent loan is flagged
`deferred_flag = 1` and asserted `eligible_reported = True`, on the story that
payments are paused under a hardship programme and so the loan is not really
past due. A disclosure row is filed to give the programme a paper trail.

Charged-off loans that had dropped off the tape are quietly put back on it under
the same story, and a cohort of new loans is written that is delinquent from the
start and deferred from the start - all of it recorded truthfully in the
servicer, all of it reported as good collateral.
"""
import bookio
import common

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance"]
START_MONTH = 9
USES_SERVICER_RECORDS = True   # only to book the new cohort truthfully
USES_COMPANY_HISTORY = False


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    ctx = common.Ctx(book_dir, borrower_id, seed)
    rng = ctx.rng

    tape = bookio.load(book_dir, "tape")
    truth = bookio.load(book_dir, "source_truth")
    disc = bookio.load(book_dir, "disclosures")

    prof = common.loan_profile(ctx, tape)
    if not prof["sample"]:
        return {"gain_usd": 0.0, "how": "borrower has no loan tape"}

    months = common.ramp(START_MONTH)
    truth_ix = {(r["month"], r["asset_id"]): r for r in truth if r["borrower_id"] == ctx.bid}

    # (a) flip existing ineligible rows to deferred-and-eligible. No servicer edit.
    flipped = 0
    for r in tape:
        if r["borrower_id"] != ctx.bid or r["month"] < START_MONTH:
            continue
        if not r["eligible_reported"]:
            r["deferred_flag"] = 1
            r["eligible_reported"] = True
            flipped += 1

    # (b) put charged-off assets back on the tape under the same story.
    on_tape = {(r["month"], r["asset_id"]) for r in tape if r["borrower_id"] == ctx.bid}
    shape = {}
    for r in tape:
        if r["borrower_id"] == ctx.bid:
            shape.setdefault(r["asset_id"], r)
    revived = []
    for (m, aid), tr in truth_ix.items():
        if m < START_MONTH or (m, aid) in on_tape or aid not in shape:
            continue
        if tr["dpd_bucket_true"] != 4:
            continue
        s = shape[aid]
        loan = {k: s[k] for k in ("orig_amount", "rate", "term", "make", "model",
                                  "model_year", "obligor_state", "credit_score",
                                  "orig_month", "vin")}
        revived.append(common.tape_row(ctx, aid, s["obligor_id"], loan, m,
                                       tr["balance_true"], dpd=3, deferred=1,
                                       eligible=True))

    # (c) a new cohort, delinquent and deferred from origination, booked honestly
    #     in the servicer and asserted as eligible on the tape.
    mint_asset = common.asset_minter(ctx, tape)
    need = ctx.target() / ctx.advance_rate
    have = sum(r["balance"] for r in tape
               if r["borrower_id"] == ctx.bid and r["month"] == common.LAST_MONTH
               and r["deferred_flag"] == 1 and r["eligible_reported"])
    have += sum(r["balance"] for r in revived if r["month"] == common.LAST_MONTH)

    new_tape, new_truth = [], []
    cohort = 0
    guard = 0
    while have < need and guard < 20000:
        guard += 1
        om = rng.choice(months[: max(1, len(months) - 2)])
        loan = common.draw_loan(ctx, prof, om)
        aid, oid = mint_asset()
        cohort += 1
        for m in range(om, common.MONTHS):
            age = m - om
            # deferred, so the balance never amortises
            bal = float(loan["orig_amount"])
            true_dpd = 0 if age == 0 else (1 if age == 1 else (2 if age == 2 else 3))
            new_truth.append(common.truth_row(ctx, aid, m, true_dpd, bal))
            new_tape.append(common.tape_row(ctx, aid, oid, loan, m, bal,
                                            dpd=true_dpd, deferred=1, eligible=True))
        have += float(loan["orig_amount"])

    disc.append({
        "borrower_id": ctx.bid,
        "kind": "deferment_program",
        "counterparty_entity_id": None,
        "start_month": int(START_MONTH),
        "note": "disclosed hardship deferment programme, rolling 12-month",
    })

    common.save(book_dir, "tape", tape + revived + new_tape)
    common.save(book_dir, "source_truth", truth + new_truth)
    bookio.save(book_dir, "disclosures", disc)

    # Gain: collateral called eligible at month 23 that the credit agreement's own
    # test (dpd <= 1) would have excluded.
    bad = 0.0
    for r in tape + revived + new_tape:
        if (r["borrower_id"] == ctx.bid and r["month"] == common.LAST_MONTH
                and r["eligible_reported"] and r["dpd_bucket_reported"] >= 2):
            bad += r["balance"]
    gain = bad * ctx.advance_rate
    return {
        "gain_usd": round(gain, 2),
        "how": (f"{flipped} rows flipped, {len(revived)} charged-off assets revived, "
                f"{cohort} born-deferred loans; ${bad:,.0f} ineligible balance "
                f"advanced at {ctx.advance_rate:.0%}"),
    }
