"""round_trip - invoices for sales that never happened, paid for with the
borrower's own money.

Follows two First Brands allegations. First, that employees "routinely submitted
fake invoices, fraudulently inflated invoices, and double-pledged invoices ...
In some instances, invoices were generated for transactions that had never
occurred, while in others the dollar amounts on invoices were altered to make
them appear more valuable." Second, that a portion of each advance was diverted
back to the company in transfers known internally as "round trips" or,
euphemistically, "corporate initiatives".

The borrower pledges invoices against customers it really trades with, using
invoice numbers and purchase-order numbers that continue its own series. An
early cohort is made to look collectible: cash leaves the operating account to a
conduit company and comes back into the collection account days later as a
remittance quoting the invoice number, so the pool appears to turn over at its
normal speed. The later cohort is never paid at all - that is where the money
stays.
"""
import bookio
import common

APPLIES_TO = ["receivables_finance"]
START_MONTH = 7
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = False

GOODS = ["units brake pads", "units spark plugs", "units fuel pumps", "units filters",
         "units wiper blades", "units alternators", "units bearings", "units gaskets",
         "units radiators", "units sensors"]


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    ctx = common.Ctx(book_dir, borrower_id, seed)
    rng = ctx.rng

    invoices = bookio.load(book_dir, "invoices")
    payments = bookio.load(book_dir, "payments")
    outflows = bookio.load(book_dir, "outflows")
    entities = bookio.load(book_dir, "entities")
    persons = bookio.load(book_dir, "persons")

    mine = [i for i in invoices if i["borrower_id"] == ctx.bid]
    if not mine:
        return {"gain_usd": 0.0, "how": "borrower pledges no invoices"}

    debtors = sorted({(i["debtor_id"], i["debtor_name"]) for i in mine})
    amounts = sorted(i["amount"] for i in mine)
    lo, hi = amounts[int(len(amounts) * 0.25)], amounts[int(len(amounts) * 0.85)]
    due_opts = sorted({i["due_days"] for i in mine}) or [45]

    # Continue the borrower's own invoice-number series.
    nums = [int(i["invoice_number"].rsplit("-", 1)[1]) for i in mine
            if i["invoice_number"].rsplit("-", 1)[1].isdigit()]
    next_num = max(nums) + 1 if nums else 10001
    mint_inv = common.invoice_minter(invoices)
    mint_t = common.txn_minter(book_dir, "payments")
    mint_o = common.txn_minter(book_dir, "outflows")

    # The conduit that sends the money back in.
    mint_e = common.entity_minter(entities)
    mint_p = common.person_minter(persons)
    nom_id = mint_p()
    persons.append({"person_id": nom_id, "name": common.person_name(rng)})
    conduit_id = mint_e()
    conduit_name = common.company_name(rng)
    entities.append(common.new_entity(
        rng, conduit_id, conduit_name, "company", nom_id, ctx.state,
        formed_month=max(0, START_MONTH - 2), has_operations=False))

    months = common.ramp(START_MONTH)
    cycled_months = months[: max(1, len(months) * 2 // 3)]   # these get paid back
    final_months = months[max(1, len(months) * 2 // 3):]     # these never do

    new_inv, new_pay, new_out = [], [], []
    cycled_face = 0.0
    unpaid_face = 0.0
    cash_out = 0.0

    def add_invoice(m, paid_back):
        nonlocal next_num
        did, dname = rng.choice(debtors)
        amt = round(rng.uniform(lo, hi), 2)
        num = f"{ctx.bid}-{next_num}"
        next_num += 1
        iid = mint_inv()
        new_inv.append({
            "borrower_id": ctx.bid,
            "invoice_id": iid,
            "facility_id": ctx.fid,
            "pledged_month": int(m),
            "invoice_number": num,
            "po_number": f"PO{rng.randint(100000, 999999)}",
            "debtor_id": did,
            "debtor_name": dname,
            "issue_month": int(m),
            "issue_day": int(rng.randint(1, 27)),
            "due_days": int(rng.choice(due_opts)),
            "amount": amt,
            "description": f"{rng.randint(80, 900)} {rng.choice(GOODS)}",
        })
        if paid_back:
            # out of the operating account, back in as a remittance a few weeks later
            pay_m = min(common.LAST_MONTH, m + rng.choice([1, 1, 2]))
            day_out = rng.randint(1, 20)
            new_out.append(common.outflow_row(
                ctx, mint_o(), pay_m, day_out, conduit_id, conduit_name,
                amt, "vendor payment"))
            new_pay.append(common.payment_row(
                ctx, mint_t(), pay_m, min(28, day_out + rng.randint(3, 8)),
                did, dname, amt, f"REMIT {num}", num))
        return amt

    # Enough unpaid face to clear the bar, net of the cash spent on the cycle.
    target = ctx.target()
    per_cycle = max(1, int(len(mine) / 24 * 0.25))
    for m in cycled_months:
        for _ in range(per_cycle):
            a = add_invoice(m, True)
            cycled_face += a
            cash_out += a

    guard = 0
    while (unpaid_face * ctx.advance_rate) - (cash_out * (1 - ctx.advance_rate)) < target \
            and guard < 5000:
        guard += 1
        m = rng.choice(final_months)
        unpaid_face += add_invoice(m, False)

    bookio.save(book_dir, "entities", entities)
    bookio.save(book_dir, "persons", persons)
    common.save(book_dir, "invoices", invoices + new_inv)
    common.save(book_dir, "payments", payments + new_pay)
    common.save(book_dir, "outflows", outflows + new_out)

    gain = unpaid_face * ctx.advance_rate - cash_out * (1 - ctx.advance_rate)
    return {
        "gain_usd": round(gain, 2),
        "how": (f"{len(new_inv)} invented invoices; ${cycled_face:,.0f} cycled back "
                f"through {conduit_name} to look collectible, ${unpaid_face:,.0f} "
                f"left outstanding at {ctx.advance_rate:.0%}"),
    }
