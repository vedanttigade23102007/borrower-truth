# alias_participations

**Story.** Double-book fractional interests in real loans already fully pledged. Extra asset IDs describe purported separately fundable participations, while the original whole loans remain in the pool. The servicer ledger repeats the false interests.

**Allegation followed.** allegations/doj-tricolor.txt and allegations/sec-tricolor-2026-77.txt: alleged double pledging of loan collateral. This adapts the mechanism to consumer and real-estate loans; it does not assert those asset classes were part of Tricolor’s alleged conduct. All supplied case descriptions are treated as allegations, not established facts. Only the supplied text files were used; their source URLs were not visited.

**Scope and timing.** Applies to consumer_finance, real_estate_finance; starts at month 6. Derives borrower, facility, asset, customer, and account IDs from the input book. Uses the seed for generated IDs and any random choices. Each invocation is intended for one initially honest borrower, once, on a fresh book.

**Levers.** Own loan tape, own source_truth, financial statements, and removal of own PledgeCheck enrollment rows from month 6 onward. Original loan, customer and contract characteristics remain unchanged; only added participation IDs and proportionate balances are new. No public ABS offering is invented.

Servicer records: **True**. Company history: **False**. Existing customer accomplice: **False**.

**Gain and accounting.** 6% of the facility limit, apart from float32 storage rounding: advance rate times the duplicated fractional principal at month 6, capped at facility and borrower limits. The same false interests persist with their underlying balances but are counted only once.

For collateral scenarios, the supplied book has no bank draw/disbursement ledger or exact underwriting rules. The calculation therefore models a borrower drawing the incremental borrowing capacity at the stated advance rate. It applies both facility limits and the borrower’s aggregate facility_limit. The baseline uses reported eligible loan balances or unpaid pledged invoice balances; it is not a discovered eligibility or detection rule. Gain is a modeled unauthorized advance, not proof the bank actually disbursed it. An unsupported input with insufficient headroom raises an explicit error before saving, rather than inventing gain. All gains are computed from the edits; repeated monthly snapshots are never summed as new proceeds.

**Why monitoring might miss it.** Asset-ID-based reconciliation can treat an alias as a separate participation when the servicer also lists it. Reconciliation to original contracts, customer-level exposure, participation ownership evidence, or investigation of stopped PledgeCheck enrollment can expose the double count.

**Blindness statement.** The design used only README.md, TABLES.md, allegations/, bookio.py, example_attack/, and sample_book/ in the supplied archive. No bank-checking implementation or hidden detection thresholds were found or used. No internet research was performed. The only internet use was the user-authorized installation of pyarrow and numpy. Monitoring effectiveness has not been measured.

**Run.** Put this folder on Python’s module path, import plant, then call `plant.plant(book_dir, borrower_id, seed)`. Requires Python 3.10+, pyarrow, and the included unmodified bookio.py. No other dependencies, network calls, environment-specific paths, or sample borrower IDs are embedded.

**Validation.** Passed 12 offline invocations on independent copies of sample_book/: all 9 applicable sample borrowers with seed 20261002, one alternate-seed test (709) for each supported borrower type, and one exact replay to check determinism. Independently recomputed sample gain: 6.000100%–6.000100% of facility_limit. Tests used the real pyarrow 25.0.1 and supplied bookio.save. They checked schema preservation, no edits to bank history or other borrowers, permitted payer identities, prior customer prefunding, truthful lever flags, no pre-start borrower data changes, unique row identifiers, facility/borrower caps, and the 5% minimum. Original sample parquet hashes remained unchanged. These are input-integrity and accounting tests, not tests of the bank’s monitoring. Fresh unseen books and detection rates are untested.
