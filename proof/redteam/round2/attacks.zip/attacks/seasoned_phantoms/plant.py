"""seasoned_phantoms: fictitious loans whose payment history is faked by existing customers acting as accomplices."""
import random
import bookio
from common import borrower_info, max_suffix, fake_vin

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance"]
START_MONTH = 16
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = False

TARGET_FRACTION = 0.12     # net gain target, after counting every dollar sent to the accomplices as a cost
N_LOANS = 6
INSTALMENT = 0.03          # monthly payment as a share of the fake loan's balance


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    rng = random.Random(seed)
    b, w = borrower_info(book_dir, borrower_id)
    limit, adv, facility_id = b["facility_limit"], w["advance_rate"], w["facility_id"]

    tape = bookio.load(book_dir, "tape")
    mine = [r for r in tape if r["borrower_id"] == borrower_id]
    payments = bookio.load(book_dir, "payments")
    outflows = bookio.load(book_dir, "outflows")

    total_paid, names = {}, {}
    for p in payments:
        if p["borrower_id"] == borrower_id:
            total_paid[p["payer_id"]] = total_paid.get(p["payer_id"], 0.0) + p["amount"]
            names.setdefault(p["payer_id"], p["payer_name"])
    on_tape = {r["obligor_id"]: r for r in mine if r["month"] == START_MONTH - 1}
    accomplices = sorted(on_tape, key=lambda o: total_paid.get(o, 0.0))[:N_LOANS]   # customers with the smallest payment history
    if len(accomplices) < N_LOANS:
        raise ValueError("not enough customers on the tape")

    n_pay = 23 - START_MONTH
    existing = sum(total_paid.get(o, 0.0) for o in accomplices)
    # solve adv*P - 1.01*(existing + n_pay*INSTALMENT*P) = target  for the total fake balance P
    P = (TARGET_FRACTION * limit + 1.01 * existing) / (adv - 1.01 * n_pay * INSTALMENT)
    per_loan = P / N_LOANS

    seq = max_suffix([r["asset_id"] for r in mine]) + 1
    pool = [r for r in mine if r["month"] == START_MONTH - 1]
    coll = next((p["account_id"] for p in payments if p["borrower_id"] == borrower_id), f"{facility_id}-COLL")
    oper = next((o["account_id"] for o in outflows if o["borrower_id"] == borrower_id), f"{facility_id}-OPER")
    nxt_pay = max(int(p["txn_id"][1:]) for p in payments) + 1
    nxt_out = max(int(o["txn_id"][1:]) for o in outflows) + 1

    new_tape, new_pay, new_out = [], [], []
    fake_total0 = 0.0
    for i, obl in enumerate(accomplices):
        t = rng.choice(pool)
        bal0 = per_loan * rng.uniform(0.9, 1.1)
        fake_total0 += bal0
        asset_id = f"A-{borrower_id}-{seq + i:06d}"
        vin = fake_vin(rng)
        for m in range(START_MONTH, 24):
            row = dict(t)
            row.update({"month": m, "facility_id": facility_id, "borrower_id": borrower_id, "asset_id": asset_id, "vin": vin,
                        "obligor_id": obl, "balance": float(bal0 * (1 - 0.02 * (m - START_MONTH))), "dpd_bucket_reported": 0,
                        "deferred_flag": 0, "eligible_reported": True, "orig_month": START_MONTH - rng.randint(1, 6),
                        "orig_amount": float(bal0 * 1.02)})
            new_tape.append(row)
        paid_fake = 0.0
        for m in range(START_MONTH + 1, 24):
            amt = round(bal0 * INSTALMENT * rng.uniform(0.98, 1.02), 2)
            paid_fake += amt
            new_pay.append({"txn_id": f"T{nxt_pay + len(new_pay):09d}", "month": m, "day": rng.randint(2, 27), "borrower_id": borrower_id,
                            "account_id": coll, "payer_id": obl, "payer_name": names.get(obl, obl), "amount": amt,
                            "memo": "loan payment", "ref": asset_id})
        # the operating account pays the customer first, and at least as much as the customer ever pays back
        new_out.append({"txn_id": f"O{nxt_out + i:09d}", "month": START_MONTH, "day": 1, "borrower_id": borrower_id, "account_id": oper,
                        "payee_id": obl, "payee_name": names.get(obl, obl), "amount": round((total_paid.get(obl, 0.0) + paid_fake) * 1.01 + 1, 2),
                        "memo": "customer refund"})
    tape.extend(new_tape); payments.extend(new_pay); outflows.extend(new_out)
    bookio.save(book_dir, "tape", tape); bookio.save(book_dir, "payments", payments); bookio.save(book_dir, "outflows", outflows)

    cost = sum(o["amount"] for o in new_out)
    gain = adv * fake_total0 - cost
    return {"gain_usd": float(gain),
            "how": f"{N_LOANS} fictitious loans (${fake_total0:,.0f}) given a payment history by {N_LOANS} existing customers who are paid "
                   f"${cost:,.0f} first; gain = advance on fake balance minus all cash sent to the customers (conservative)"}
