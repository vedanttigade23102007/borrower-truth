# customer_roundtrip

**Story.** Add fictitious invoices to an existing real customer acting as an accomplice. Fund a small apparent invoice payment through a visible operating-account transfer to that customer before it pays the collection account. Most of the fictitious balance remains outstanding.

**Allegation followed.** allegations/doj-first-brands.txt: alleged fake invoices and self-payments termed round trips. Using an existing customer as the returning payer is this synthetic scenario’s adaptation, not a claim that the supplied release alleges that exact route. All supplied case descriptions are treated as allegations, not established facts. Only the supplied text files were used; their source URLs were not visited.

**Scope and timing.** Applies to receivables_finance; starts at month 6. Derives borrower, facility, asset, customer, and account IDs from the input book. Uses the seed for generated IDs and any random choices. Each invocation is intended for one initially honest borrower, once, on a fresh book.

**Levers.** Own invoices and financial/SEC revenue reports; append only an operating outflow and an incoming payment per fictitious invoice. The payer is an existing customer on this borrower’s original invoices. Every return is fully prefunded to that same customer on an earlier day.

Servicer records: **False**. Company history: **False**. Existing customer accomplice: **True**.

**Gain and accounting.** A conservative 6% net of the facility limit: 7% additional collateral-based advance after deducting the returning payment from invoice face value, less 1% of the limit spent prefunding the accomplice. The returning 1% is never counted as external income or additional gain. The outflow deduction is conservative because the funds return to the controlled collection account.

For collateral scenarios, the supplied book has no bank draw/disbursement ledger or exact underwriting rules. The calculation therefore models a borrower drawing the incremental borrowing capacity at the stated advance rate. It applies both facility limits and the borrower’s aggregate facility_limit. The baseline uses reported eligible loan balances or unpaid pledged invoice balances; it is not a discovered eligibility or detection rule. Gain is a modeled unauthorized advance, not proof the bank actually disbursed it. An unsupported input with insufficient headroom raises an explicit error before saving, rather than inventing gain. All gains are computed from the edits; repeated monthly snapshots are never summed as new proceeds.

**Why monitoring might miss it.** The bank receipt names a genuine existing customer, so payer-identity checks alone cannot establish independent collections. The matching earlier operating outflow is left fully visible; cross-account cash-flow analysis and customer confirmation can expose the circular payment.

**Blindness statement.** The design used only README.md, TABLES.md, allegations/, bookio.py, example_attack/, and sample_book/ in the supplied archive. No bank-checking implementation or hidden detection thresholds were found or used. No internet research was performed. The only internet use was the user-authorized installation of pyarrow and numpy. Monitoring effectiveness has not been measured.

**Run.** Put this folder on Python’s module path, import plant, then call `plant.plant(book_dir, borrower_id, seed)`. Requires Python 3.10+, pyarrow, and the included unmodified bookio.py. No other dependencies, network calls, environment-specific paths, or sample borrower IDs are embedded.

**Validation.** Passed 15 offline invocations on independent copies of sample_book/: all 13 applicable sample borrowers with seed 20261002, one alternate-seed test (709) for each supported borrower type, and one exact replay to check determinism. Independently recomputed sample gain: 6.000000%–6.000000% of facility_limit. Tests used the real pyarrow 25.0.1 and supplied bookio.save. They checked schema preservation, no edits to bank history or other borrowers, permitted payer identities, prior customer prefunding, truthful lever flags, no pre-start borrower data changes, unique row identifiers, facility/borrower caps, and the 5% minimum. Original sample parquet hashes remained unchanged. These are input-integrity and accounting tests, not tests of the bank’s monitoring. Fresh unseen books and detection rates are untested.
