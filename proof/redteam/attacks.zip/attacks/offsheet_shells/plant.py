"""offsheet_shells - borrowings parked in companies that are not on the balance
sheet.

Follows the First Brands allegation about the "James Entities": companies
"wholly owned and controlled by PATRICK JAMES ... nominally separate from First
Brands [but which] had no independent business operations", used to take
inventory financing from three lenders, "maintained outside the First Brands
corporate balance sheet and thereby concealed from First Brands' senior
lenders, who routinely requested and received First Brands' financial
statements."

The borrower buys aged companies and dresses them up: they are decades old on
the register, they show a real business, their officers are nominees, and each
one uses a different registered agent and a different state. One of them takes
an LEI, so a lookup finds a real-looking company rather than nothing. They
borrow; the borrower gets the money; the quarterly debt figure the bank receives
never moves, and the covenant metric is nudged to keep its honest-looking
trajectory rather than sagging under the new leverage.

This is the attack that leans hardest on faked company history, which is also
the part a real borrower can only partly buy.
"""
import bookio
import common

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance",
              "receivables_finance"]
START_MONTH = 6
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = True


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    ctx = common.Ctx(book_dir, borrower_id, seed)
    rng = ctx.rng

    entities = bookio.load(book_dir, "entities")
    persons = bookio.load(book_dir, "persons")
    gleif = bookio.load(book_dir, "gleif")
    outflows = bookio.load(book_dir, "outflows")
    fin = bookio.load(book_dir, "financials")

    mint_e = common.entity_minter(entities)
    mint_p = common.person_minter(persons)
    states = ["DE", "NV", "WY", "TX", "FL", "NJ", "IL", "NC"]

    shells = []
    for k in range(3):
        pid = mint_p()
        pname = common.person_name(rng)
        persons.append({"person_id": pid, "name": pname})
        eid = mint_e()
        ename = common.company_name(rng)
        entities.append(common.new_entity(
            rng, eid, ename, "company", pid,
            rng.choice([s for s in states if s != ctx.state]),
            formed_month=-rng.randint(96, 300),   # an aged shelf company
            has_operations=True,                  # dressed to look like a business
            agent=rng.choice(common.AGENTS)))
        shells.append((eid, ename, pid, pname))

    # One shell takes an LEI so a register lookup returns something.
    tails = [int(g["lei"][6:]) for g in gleif if g["lei"].startswith("SYNLEI") and g["lei"][6:].isdigit()]
    nxt = (max(tails) + 1) if tails else 1
    gleif.append({
        "lei": f"SYNLEI{nxt:014d}",
        "entity_id": shells[0][0],
        "legal_name": shells[0][1],
        "parent_entity_id": None,
    })

    # Draw the hidden facilities down across the window.
    months = common.ramp(START_MONTH, common.LAST_MONTH - 1)
    total = ctx.target()
    picks = sorted(rng.sample(months, min(6, len(months))))
    weights = [common.smooth_share(i, len(picks)) + 0.5 for i in range(len(picks))]
    scale = total / sum(weights)
    schedule = {}
    for (m, w) in zip(picks, weights):
        schedule[m] = schedule.get(m, 0.0) + w * scale

    mint_o = common.txn_minter(book_dir, "outflows")
    rate = 0.155 / 12.0
    new_out = []
    outstanding = 0.0
    for m in range(START_MONTH, common.MONTHS):
        outstanding += schedule.get(m, 0.0)
        if outstanding <= 0:
            continue
        eid, ename, _, _ = shells[m % len(shells)]
        new_out.append(common.outflow_row(
            ctx, mint_o(), m, rng.randint(2, 27), eid, ename,
            outstanding * rate * rng.uniform(0.95, 1.05), "vendor payment"))

    # The quarterly pack never shows the new leverage; the covenant metric is
    # held on its honest-looking path.
    mine = sorted([f for f in fin if f["borrower_id"] == ctx.bid], key=lambda r: r["quarter"])
    first_q = (START_MONTH - 2) // 3
    touched = 0
    for i, row in enumerate(mine):
        if row["quarter"] < first_q or i == 0:
            continue
        prev = mine[i - 1]
        if row["covenant_metric_reported"] < prev["covenant_metric_reported"]:
            row["covenant_metric_reported"] = round(
                prev["covenant_metric_reported"] * rng.uniform(1.00, 1.03), 4)
            touched += 1

    bookio.save(book_dir, "entities", entities)
    bookio.save(book_dir, "persons", persons)
    bookio.save(book_dir, "gleif", gleif)
    bookio.save(book_dir, "financials", fin)
    common.save(book_dir, "outflows", outflows + new_out)

    gain = sum(schedule.values())
    return {
        "gain_usd": round(gain, 2),
        "how": (f"${gain:,.0f} borrowed through {len(shells)} nominee-owned shelf "
                f"companies, undisclosed; debt_reported untouched, "
                f"{touched} covenant readings smoothed"),
    }
