# seasoned_phantoms

**Story.** An improved `phantom_collateral`. From month 16 the borrower adds 6 fictitious loans, but each is assigned to an **existing customer** already on its tape, and that customer makes a monthly payment on it into the collection account (3% of balance, months 17-23, memo "loan payment", ref = the fake loan). So the fake loans have a payment history. To make the money real, the operating account first pays each customer a "customer refund" on month 16 day 1 that is at least what that customer will ever pay back (all of their existing payments plus the new ones, +1%).

**Allegation followed.** None; this one is new. It exists to use the "customer as accomplice" lever, which the First Brands round-trip description ("round trips" and self-payments) loosely resembles.

**Levers.** Its own tape; money it moves (outflows to the customers, then their payments in); **existing customers as accomplices**. No servicer records, no company history.

**Gain.** `advance_rate x fake balance at month 16 - every dollar sent to the accomplices`. Counting all the cash as a cost is deliberately conservative: much of it comes back and pays down the facility. Sized so the net is about 12% of `facility_limit`; that needs fake loans of about 20% of the limit, so they are a large share of a small book.

**Why monitoring might miss it.** It defeats the "performing loan with no payments" test and a payer-versus-obligor match, because the payer is exactly the obligor. Honest weak points:
- the same obligor ID carries two loans, one real and one fake, with different terms;
- the operating account pays each of these customers a lump sum just before they start paying;
- the customers were chosen for small payment histories, so a customer who suddenly pays far more than their loan history is unusual;
- it only starts at month 16, so the seasoning is short.
