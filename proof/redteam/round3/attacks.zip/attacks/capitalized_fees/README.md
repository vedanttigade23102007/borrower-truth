# capitalized_fees

**Story.** Add unauthorized servicing charges to otherwise genuine current loans, capitalize those charges into principal, and report that principal as collateral. The charges are not customer obligations. Both tape and servicer balances are padded by the same amount.

**Allegation followed.** Original synthetic scenario. It is conceptually related to collateral-value manipulation but is not presented as a specific allegation in the supplied releases. All supplied case descriptions are treated as allegations, not established facts. Only the supplied text files were used; their source URLs were not visited.

**Scope and timing.** Applies to auto_finance, consumer_finance, real_estate_finance; starts at month 6. Derives borrower, facility, asset, customer, and account IDs from the input book. Uses the seed for generated IDs and any random choices. Each invocation is intended for one initially honest borrower, once, on a fresh book.

**Levers.** Own tape balances, own source_truth balances, financial statements, and existing own SEC revenue reports. Delinquency, customer IDs, original contractual amounts, payments, liens, and PledgeCheck results are untouched.

Servicer records: **True**. Company history: **False**. Existing customer accomplice: **False**.

**Gain and accounting.** 6% of the facility limit, apart from float32 rounding, from one advance against unauthorized capitalized fees at month 6. The fee residual stays on surviving loans; reporting it again in subsequent months is not additional gain.

For collateral scenarios, the supplied book has no bank draw/disbursement ledger or exact underwriting rules. The calculation therefore models a borrower drawing the incremental borrowing capacity at the stated advance rate. It applies both facility limits and the borrower’s aggregate facility_limit. The baseline uses reported eligible loan balances or unpaid pledged invoice balances; it is not a discovered eligibility or detection rule. Gain is a modeled unauthorized advance, not proof the bank actually disbursed it. An unsupported input with insufficient headroom raises an explicit error before saving, rather than inventing gain. All gains are computed from the edits; repeated monthly snapshots are never summed as new proceeds.

**Why monitoring might miss it.** Matching tape and servicer balances may pass a comparison between those two borrower-controlled sources. Original contracts, fee authorization evidence, and principal roll-forward reconciliation against bank receipts can reveal the overstatement.

**Blindness statement.** The design used only README.md, TABLES.md, allegations/, bookio.py, example_attack/, and sample_book/ in the supplied archive. No bank-checking implementation or hidden detection thresholds were found or used. No internet research was performed. The only internet use was the user-authorized installation of pyarrow and numpy. Monitoring effectiveness has not been measured.

**Run.** Put this folder on Python’s module path, import plant, then call `plant.plant(book_dir, borrower_id, seed)`. Requires Python 3.10+, pyarrow, and the included unmodified bookio.py. No other dependencies, network calls, environment-specific paths, or sample borrower IDs are embedded.

**Validation.** Passed 24 offline invocations on independent copies of sample_book/: all 20 applicable sample borrowers with seed 20261002, one alternate-seed test (709) for each supported borrower type, and one exact replay to check determinism. Independently recomputed sample gain: 6.000100%–6.000100% of facility_limit. Tests used the real pyarrow 25.0.1 and supplied bookio.save. They checked schema preservation, no edits to bank history or other borrowers, permitted payer identities, prior customer prefunding, truthful lever flags, no pre-start borrower data changes, unique row identifiers, facility/borrower caps, and the 5% minimum. Original sample parquet hashes remained unchanged. These are input-integrity and accounting tests, not tests of the bank’s monitoring. Fresh unseen books and detection rates are untested.
