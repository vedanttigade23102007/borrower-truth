# month_end_cure

**Story.** A loan sixty days down is not eligible collateral. A loan that is
current is. So shortly before each reporting date the borrower pays its own
customers' arrears, out of its own pocket, in the smallest amount that will roll
each loan back to current. The money goes out of the operating account to a
payment processor and arrives in the collection account attributed to the
customer, referencing the right loan. The borrower also carries a cohort of
loans that has never paid a cent and is cured this way every single month, so it
sits at full balance and perfect delinquency for the life of the facility.

What makes this different from the other collateral attacks is that nothing in
the record is false. The payment really was received. The servicer really does
show the loan current - and so the servicer update here is truthful, not
fabricated. The tape really does agree with the servicer. The loan really does
satisfy the eligibility test as written. The only false thing is an implication
nobody writes down: that the customer paid.

**Allegation it follows.** None. This is new. It is the mirror image of
`deferment_mask`: that attack lies about eligibility while telling the truth
about delinquency, this one tells the truth about everything and buys the
delinquency it wants.

**Levers.** Payments into the collection account. Outflows from the operating
account. The loan tape. The servicer system, truthfully - the cure genuinely
posts.

**Gain.** The advance rate applied to the balance that is eligible at month 23
only because it was cured, less every dollar of the borrower's own cash fed in
to achieve it. Netting the cash matters: this attack is expensive to run, and a
gross figure would flatter it. About 6.7% of `facility_limit` net.

**Why monitoring would miss it.** Consistency checks are the wrong instrument
here, because the data is consistent - that is the design. Tie-outs pass, payment
reconciliation passes, eligibility as written passes, and the delinquency
profile looks better than the honest book rather than worse.

It is findable, but only by looking at behaviour. Curing payments cluster into
the last days of the month, where the honest book's payments are spread across
it. They are sized to the minimum that moves a bucket, not to a contractual
instalment. They land on obligors who are otherwise silent and who never pay
anything else. And the cash going out to the processor each month tracks the cash
coming in from those obligors, which is a company paying itself through an
intermediary. Any one of those is weak; together they are a signature. The deeper
check is economic rather than statistical: a book where delinquency never
develops, in a subprime asset class, is not a good book, it is a managed one.
