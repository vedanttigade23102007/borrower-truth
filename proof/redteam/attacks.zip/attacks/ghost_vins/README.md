# ghost_vins

**Story.** The borrower invents loans. Over months 7 to 23 it writes several
hundred car or consumer loans that were never originated to customers who do not
exist, and pledges them. Each fake loan is given a vehicle identifier, an
obligor, an origination month, an amount, a rate, a term, a make and model, a
state and a credit score, all drawn from the shape of the borrower's own real
book so the new paper is indistinguishable from the old on any single field. The
loans are also written into the servicer system at the same balances and the
same delinquency, and each one pays every month into the collection account on
the right day in roughly the right amount. From the bank's side a fake loan was
originated, is recorded in the servicing system, and is performing.

**Allegation it follows.** Tricolor. The DOJ alleges Chu and Goodgame
"manipulate[d] the characteristics of collateral to make ineligible,
near-worthless assets appear to meet lender requirements", and that of roughly
$2.2bn pledged only $1.4bn was real. This is the simplest form of that: the
collateral is not near-worthless, it is absent.

**Levers.** The loan tape. The servicer system (`source_truth`). Payments added
into the collection account.

**Gain.** The balance of fabricated loans still standing at month 23, multiplied
by the facility's advance rate. The script sizes the cohort by originating fakes
until that figure reaches the target, so the gain lands at about 6.5% of
`facility_limit` — around $2.9m on a $45m line, $11.1m on a $171m line. The
figure is deliberately a stock, not a sum of flows: it is the advance the bank is
carrying at the end against nothing.

**Why monitoring would miss it.** There is no internal contradiction to find.
Tape agrees with servicer, balances amortise correctly, payments reconcile to the
loans they reference, delinquency is normal, the characteristics sit inside the
borrower's own historical distributions, and the book grows on a smooth curve
rather than jumping. Everything that could be cross-checked against another table
in this schema has been made to agree.

What it cannot survive is anything outside the schema: a vehicle identifier
checked against a title register, a customer telephoned, a payment traced to a
real bank account rather than a row in a file. That is the point of the
attack - it marks the line between checks that compare the borrower's data to
itself and checks that compare it to the world. Note also that the quarterly
examiner sample is a real threat here in a way it is not for the other attacks,
because a sampled ghost loan has no documents behind it at all. The attack
survives monitoring; it is betting against the sample.

**Without the servicer lever** this attack should be easy. Pledged assets that
the servicing system has never heard of are the most direct tie-out there is.
