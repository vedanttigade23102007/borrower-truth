"""ghost_vins - collateral that was never originated.

Follows the Tricolor allegation that executives "manipulated the characteristics
of collateral to make ineligible, near-worthless assets appear to meet lender
requirements" and pledged ~$800m of bogus collateral.

The borrower invents loans. Each one gets a tape row, a matching servicer record,
and a monthly payment into the collection account, so the loan looks originated,
booked and performing from every angle the bank can see.
"""
import bookio
import common

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance"]
START_MONTH = 7
USES_SERVICER_RECORDS = True
USES_COMPANY_HISTORY = False


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    ctx = common.Ctx(book_dir, borrower_id, seed)
    rng = ctx.rng

    tape = bookio.load(book_dir, "tape")
    truth = bookio.load(book_dir, "source_truth")
    payments = bookio.load(book_dir, "payments")

    prof = common.loan_profile(ctx, tape)
    if not prof["sample"]:
        return {"gain_usd": 0.0, "how": "borrower has no loan tape to imitate"}

    mint_asset = common.asset_minter(ctx, tape)
    mint_txn = common.txn_minter(book_dir, "payments")

    months = common.ramp(START_MONTH)
    need = ctx.target() / ctx.advance_rate  # fake balance required at month 23

    # Originate fakes across the window, weighted late so the book looks like it
    # is growing rather than jumping.
    fakes = []
    standing = 0.0
    guard = 0
    while standing < need and guard < 20000:
        guard += 1
        i = rng.randrange(len(months))
        w = common.smooth_share(i, len(months))
        if rng.random() > 0.25 + 0.75 * w:
            continue
        om = months[i]
        loan = common.draw_loan(ctx, prof, om)
        bal23 = common.balance_at(loan, common.LAST_MONTH)
        if not bal23:
            continue
        aid, oid = mint_asset()
        fakes.append((aid, oid, loan, common.person_name(rng)))
        standing += bal23

    new_tape, new_truth, new_pay = [], [], []
    for aid, oid, loan, who in fakes:
        pmt = common.monthly_payment(loan)
        for m in range(loan["orig_month"], common.MONTHS):
            bal = common.balance_at(loan, m)
            if bal is None or bal <= 0:
                break
            new_tape.append(common.tape_row(ctx, aid, oid, loan, m, bal))
            new_truth.append(common.truth_row(ctx, aid, m, 0, bal))
            if m > loan["orig_month"]:
                new_pay.append(common.payment_row(
                    ctx, mint_txn(), m, rng.randint(2, 27), oid, who,
                    pmt * rng.uniform(0.97, 1.03), "loan payment", aid))

    common.save(book_dir, "tape", tape + new_tape)
    common.save(book_dir, "source_truth", truth + new_truth)
    common.save(book_dir, "payments", payments + new_pay)

    final = sum(r["balance"] for r in new_tape if r["month"] == common.LAST_MONTH)
    gain = final * ctx.advance_rate
    return {
        "gain_usd": round(gain, 2),
        "how": (f"{len(fakes)} fabricated loans carried to month 23 at "
                f"${final:,.0f}, advanced at {ctx.advance_rate:.0%}"),
    }
