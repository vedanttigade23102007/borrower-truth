# phantom_collateral

**Story.** The borrower adds 7 loans to its pledged tape that do not exist: invented loan IDs, invented customers, invented VINs. Each copies the profile (make, model, year, state, score, rate, term) of a *different* real loan from the same book, and is reported current and eligible every month from month 4, with a slow believable amortisation. IDs continue the borrower's own numbering, and VINs use the same format as real ones.

**Allegation followed.** DOJ, *US v. Chu et al.* (Tricolor): about $2.2bn pledged against about $1.4bn of real collateral, roughly $800m of it "bogus", with collateral characteristics manipulated so ineligible or worthless assets looked eligible.

**Levers.** Its own loan tape only. No servicer records, no company history, no accomplice.

**Gain.** `advance_rate x fake balance at month 4`, sized at about 17% of `facility_limit` (7 loans of about 2.4% each). Tested at 17.0-18.0% on every auto, consumer and real-estate borrower in the sample book.

**Why monitoring might miss it.** On the tape alone nothing is out of range: the fake loans look like the borrower's own loans, and they are current, so they create no delinquency signal. Honest weak points:
- they have **no payments** in `payments` at all, which is the main tell;
- they are absent from `source_truth`, so any records pull or examiner sample that reaches them finds nothing;
- a lender that checks payment history against tape balances would see seven "performing" loans that never pay.

I chose not to fake the payments here (an added payment cannot come from an invented customer). `seasoned_phantoms` covers that variant.
