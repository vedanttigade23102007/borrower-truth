# round_trip

**Story.** The borrower is an invoice-finance company. From month 7 it pledges
invoices for sales that never happened. They are raised against customers it
genuinely trades with, carry invoice numbers that continue its own series,
purchase-order numbers in its own format, amounts inside its own range, and
descriptions of the goods it actually deals in.

An early cohort is made to look collectible. Cash leaves the operating account
to a conduit company and returns to the collection account a few weeks later as a
remittance quoting the invoice number, so the pool appears to turn over at its
normal speed and the customers appear to be paying. That cohort costs the
borrower money - it pays a dollar to have received eighty-five cents - and it
exists only to buy credibility for the pool.

The later cohort is simply never paid. By the time anyone asks, the advances
have been drawn and the invoices are merely overdue, which is a commercial
problem rather than a criminal one.

**Allegation it follows.** First Brands, twice over. Employees "routinely
submitted fake invoices, fraudulently inflated invoices, and double-pledged
invoices ... In some instances, invoices were generated for transactions that had
never occurred". And a portion of each advance was cycled back to the company in
transfers known internally as "round trips" or "corporate initiatives".

**Levers.** Invoices. Payments into the collection account. Outflows from the
operating account. A new company, formed during the facility, no operations, as
the conduit. No servicer access and no faked company history.

**Gain.** The advance rate applied to the face of the invoices left outstanding
at the end, less the cost of the cycled cohort - the fifteen cents in the dollar
the borrower lost on every invoice it paid for itself. About 6.6% of
`facility_limit`.

**Why monitoring would miss it.** The invoices look like the borrower's other
invoices in every field, and are spread across real debtors rather than piled on
one. Dilution looks normal because the early cohort is paid on time. There is no
concentration spike, no new debtor to raise an eyebrow, no gap in the numbering.

The thread worth pulling is the round trip itself. Money leaves the operating
account to one new payee and comes back into the collection account days later,
attributed to a customer, in amounts that match. The match is not exact in timing
and the payer identity is rewritten in between, so it survives a naive join - but
a check that compares outflow totals to a conduit against subsequent inflow
totals, over a window rather than transaction by transaction, sees a company
funding its own receipts. The second thread is that the final cohort never pays
at all, so the ageing of the pool deteriorates sharply right at the end of the
window, which is exactly when it is least convenient to notice.
