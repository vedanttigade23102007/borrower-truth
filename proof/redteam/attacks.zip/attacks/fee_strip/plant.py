"""fee_strip - the cash leaves through a servicing contract with the owner.

Not from the allegations, though it rhymes with the IRS-CI line that First
Brands' principals used new loan proceeds "to fund their extravagant
lifestyle". Nothing about the collateral is misstated here. The loans are real,
the tape is honest, the servicer agrees, the registry is clean. The borrower is
simply being hollowed out from the operating account.

The owner sets up a management company and a back-office company and signs the
borrower to a servicing agreement priced far above the market. Money leaves
every month as ordinary vendor payments, split across two payees and varied
enough not to look like a standing order. By the time the facility is in
trouble the cash is gone, and the bank's recovery is against a shell.

Two details do the concealment. The related party is disclosed - but only one of
the two companies is, and the disclosed note describes it as a back-office
vendor rather than an entity the owner controls. And the officer named on the
register for each company is a nominee, not the borrower's owner, so a search on
the owner's name does not connect them.
"""
import bookio
import common

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance",
              "receivables_finance"]
START_MONTH = 5
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = True   # one vehicle is an aged company showing operations


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    ctx = common.Ctx(book_dir, borrower_id, seed)
    rng = ctx.rng

    entities = bookio.load(book_dir, "entities")
    persons = bookio.load(book_dir, "persons")
    outflows = bookio.load(book_dir, "outflows")
    disc = bookio.load(book_dir, "disclosures")

    mint_e = common.entity_minter(entities)
    mint_p = common.person_minter(persons)

    vehicles = []
    for k in range(2):
        pid = mint_p()
        persons.append({"person_id": pid, "name": common.person_name(rng)})
        eid = mint_e()
        ename = common.company_name(rng)
        entities.append(common.new_entity(
            rng, eid, ename, "company", pid, ctx.state,
            formed_month=(-rng.randint(48, 180) if k == 0 else max(0, START_MONTH - 4)),
            has_operations=(k == 0)))
        vehicles.append((eid, ename))

    # Only the second one is disclosed, and only as a vendor.
    disc.append({
        "borrower_id": ctx.bid,
        "kind": "related_party",
        "counterparty_entity_id": vehicles[1][0],
        "start_month": int(START_MONTH),
        "note": "back-office servicing vendor",
    })

    months = common.ramp(START_MONTH)
    total = ctx.target()
    weights = [0.6 + common.smooth_share(i, len(months)) for i in range(len(months))]
    scale = total / sum(weights)

    mint_o = common.txn_minter(book_dir, "outflows")
    new_out = []
    extracted = 0.0
    for i, m in enumerate(months):
        due = weights[i] * scale
        # split across the two payees, uneven, with a mix of memos
        a = due * rng.uniform(0.45, 0.70)
        b = due - a
        for (eid, ename), amt in zip(vehicles, (a, b)):
            if amt <= 0:
                continue
            new_out.append(common.outflow_row(
                ctx, mint_o(), m, rng.randint(2, 27), eid, ename,
                amt * rng.uniform(0.97, 1.03),
                rng.choice(["vendor payment", "vendor payment", "rent"])))
            extracted += amt

    bookio.save(book_dir, "entities", entities)
    bookio.save(book_dir, "persons", persons)
    bookio.save(book_dir, "disclosures", disc)
    common.save(book_dir, "outflows", outflows + new_out)

    return {
        "gain_usd": round(extracted, 2),
        "how": (f"${extracted:,.0f} taken out over {len(months)} months as servicing "
                f"and rent to {vehicles[0][1]} and {vehicles[1][1]}, "
                f"one disclosed as a vendor, both nominee-officered"),
    }
