# shadow_repledge

**Story.** The borrower takes enough of its real, eligible, performing loans (typically 5-15) and pledges each one a second time under a new asset ID and a new VIN. The copy follows the original's balance, delinquency and terms month by month from month 2. In a real fraud the second pledge goes to a second lender or ABS pool; here the data only shows the double count inside this bank's borrowing base, which is the only part the bank can see.

**Allegation followed.** DOJ and SEC (Tricolor, release 2026-77): the same auto loans pledged to several lenders and ABS pools, with false "free and clear" statements.

**Levers.** Its own loan tape only.

**Gain.** `advance_rate x balance of the duplicated loans at month 2`, sized at about 17% of `facility_limit`. Tested at 12-22% across 12 sample borrowers (it overshoots the target on small books because whole loans are duplicated, and falls a little short where the loans are few and large).

**Why monitoring might miss it.** Every performance field is real, because the copies are real loans. Nothing about delinquency, eligibility share or portfolio mix changes. Honest weak points:
- two different `asset_id`s share the same `obligor_id`, origination month, amount, rate and term;
- the duplicates have no payments of their own (the real loan's payments carry the original `asset_id`);
- the new VIN breaks any VIN-uniqueness test, but a duplicate on obligor and terms remains;
- for the borrowers enrolled in PledgeCheck, this attack leaves enrolment as is. A fuller version would un-enrol by removing its own rows, which would itself be a signal.
