# offsheet_shells

**Story.** The owner acquires three aged companies and dresses them up. On the
register they are eight to twenty-five years old, they show a real business, each
sits in a different state from the borrower, each uses a different registered
agent, and each is officered by a different nominee rather than by the owner. One
of them takes an LEI, so a lookup against the entity register returns a
plausible company with a legal name rather than nothing at all.

Those companies borrow. The money reaches the borrower. The quarterly financial
pack the bank receives never shows the new leverage: `debt_reported` continues on
its honest trend, and where the covenant metric would have sagged under the extra
borrowing it is written back up to its previous level, which is the "bridge
file" adjustment in miniature. Interest leaves the operating account as vendor
payments spread across the three companies, so no single payee carries a
debt-shaped series.

**Allegation it follows.** First Brands, the "James Entities": companies "wholly
owned and controlled by PATRICK JAMES ... nominally separate from First Brands
[but which] had no independent business operations", which borrowed from three
inventory financers and whose arrangements were "maintained outside the First
Brands corporate balance sheet and thereby concealed from First Brands' senior
lenders, who routinely requested and received First Brands' financial
statements." The covenant smoothing follows the separate allegation that
employees "made unsupportable financial statement adjustments to meet financial
benchmarks" and kept internal "bridge" files.

**Levers.** New companies and people, with faked history - formed before month 0
and showing operations. The LEI register, for a company the borrower controls.
Financial statements and the covenant figure. Outflows. No servicer access and
no change to the tape.

**Gain.** The principal outstanding on the concealed facilities at the end:
about 6.5% of `facility_limit`.

**Why monitoring would miss it.** The collateral is honest, so collateral checks
pass. The covenant is met in every quarter, so covenant checks pass. The new
companies do not share an officer, an address, a phone number or an agent with
the borrower or with each other, so a related-party search anchored on the
owner's name finds nothing. Their age and their apparent operations defeat the
usual shell heuristics, and the LEI makes one of them look more substantial than
most real counterparties in the book.

The weaknesses are in the money and in the smoothness. Three companies that
appeared in the borrower's outflows within a month of each other, that are paid
every month thereafter, and whose combined payments track a single rising
balance, are one arrangement wearing three coats. And a covenant metric that
stops ever falling is itself the signal - real ratios wobble, and a series that
only ever holds or improves is a series someone is managing.

**Without the company-history lever** the three vehicles are brand-new companies
with no operations, which is a much weaker disguise and should be far easier to
find. This attack is the clearest test of how much that lever is worth.
