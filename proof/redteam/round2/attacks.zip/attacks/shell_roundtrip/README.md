# shell_roundtrip

**Story.** The borrower borrows about 16% of its limit from an outside lender the bank never sees, and routes the money into its collection account through a company it quietly controls. The company is registered under a **nominee** (a person unrelated to the owner on paper) with its own address, phone and registered agent in DE, WY or NV. It is **backdated** to 5-10 years old with `has_operations = True`, and is never disclosed as a related party or as debt. Eight payments across months 6-23 carry the memo "receivable settlement" and no loan reference, like the honest "sublease rent" payments from disclosed affiliates.

**Allegation followed.** DOJ (First Brands): off-balance-sheet financing through nominally separate "James Entities" with no real operations, with loan proceeds routed through a customer-collections entity so they looked like ordinary customer receipts, hidden from the senior lenders.

**Levers.** Companies it forms (a new person and company), **the company-history lever (`USES_COMPANY_HISTORY = True`)** for the backdating and operations flag, and money it moves (payments from a company the attack creates, which the rules allow). No servicer records.

**Gain.** The total routed in: the hidden outside debt, per the brief's definition of gain. Honest caveat: because the cash lands in a bank-controlled collection account it pays down this bank's exposure, so the economic benefit to the borrower is the hidden borrowing rather than a direct draw.

**Why monitoring might miss it.** The cash is real and the payer looks like an old operating company with no link to the owner in any table I control. Honest weak points: the memo has no loan or invoice reference, payments are lumpy and unrelated to the loan book, the payer is absent from `disclosures`, and, with the history lever off, a new company with no operations would be an obvious flag (not separately scored).
