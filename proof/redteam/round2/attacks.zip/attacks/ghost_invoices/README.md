# ghost_invoices

**Story.** Every two months from month 3 the borrower pledges a batch of invoices for sales that never happened, billed to real customers already on its invoice book. Amounts, due terms and goods descriptions are drawn from the borrower's real distribution, and IDs continue its own numbering.

**Allegation followed.** DOJ, *US v. Patrick James and Edward James* (First Brands): "invoices were generated for transactions that had never occurred" and sold or pledged as valid receivables.

**Levers.** Its own invoice report only.

**Gain.** `advance_rate x peak fake face value still eligible`, sized at 14% of `facility_limit`. **Assumption (mine, not from the files):** a fake invoice stops earning an advance 90 days after its due date; the batches are spaced so only about three are alive at once. Ghost invoices are never paid and cannot be removed from the invoice table, so older ones stay on it as visibly stale items.

**Why monitoring might miss it.** Each ghost looks like any other invoice to an existing customer, and no single batch is large. Honest weak points, which I expect a competent check to find:
- ghosts are **never paid** in `payments`, unlike the honest invoices (about 91% of which are paid, by the debtor);
- the stale unpaid ghosts accumulate on the invoice table;
- a debtor confirmation on any sampled ghost fails.
I did not use the accomplice lever to fake payments for ghosts, because the outflow a debtor needs to cover everything it pays back is large for customers who pay the borrower often.
