# Red team hand-in

Eight attacks. Each is a folder with a `README.md`, a `plant.py`, and a copy of
the `common.py` helper the script imports.

| attack | trick | types | start | servicer | company history | gain |
|---|---|---|---|---|---|---|
| `ghost_vins` | loans that were never originated, written into the servicer and paying | auto, consumer, real estate | 7 | yes | no | ~6.5% |
| `deferment_mask` | delinquency reported honestly, eligibility asserted anyway under a sham deferment programme | auto, consumer, real estate | 9 | yes | no | ~6.5% |
| `double_pledge` | a second facility on the same collateral, with de-enrolment from the shared registry | all four | 8 | no | no | ~6.5% |
| `abs_overlap` | real loans sold to ABS investors and pledged to the bank at once, across reports with no shared key | auto | 6 | yes | no | ~6.5% |
| `round_trip` | invoices for sales that never happened, early ones paid with the borrower's own cash | receivables | 7 | no | no | ~6.6% |
| `offsheet_shells` | aged nominee-owned companies carry undisclosed debt; covenant readings smoothed | all four | 6 | no | yes | ~6.5% |
| `month_end_cure` | the borrower pays its customers' arrears so the loans are genuinely current | auto, consumer, real estate | 10 | yes | no | ~6.7% |
| `fee_strip` | cash taken out through an inflated related-party servicing contract | all four | 5 | no | yes | ~6.5% |

Gain is quoted as a percentage of the borrower's `facility_limit`. Six of the
eight follow an allegation in `allegations/`; `month_end_cure` and `fee_strip`
are new.

## Testing

Every script was run on a copy of `sample_book/` across every eligible borrower
and three seeds - 573 runs. All completed without error, `bookio.save` accepted
every table written, every table reloaded cleanly afterwards, no run touched
`borrowers`, `facilities`, `ucc_filings` or `court_records`, and the lowest gain
in any run was 6.50% of `facility_limit`. Three attacks planted into one book at
once produced no id collisions.

## Things in the files that may reveal how the bank checks

Rule 5 asks me to say where the briefing looked like it was leaking the
detector, and not to use those things.

**The `pledgecheck` columns.** `uniqueness`, `data_integrity`, `completeness`
and `single_record` are named like four specific tests rather than like data. I
have treated the table only as a third-party result the bank receives, and the
one thing I do with it is stop being enrolled, which rule 1 explicitly permits.
No attack is designed around what those four flags do or do not catch, and
nothing is tuned to keep any of them reading PASS.

**The honest book's tolerance for disagreement.** In `sample_book/` the tape and
the servicer disagree on delinquency for 67 of 44,628 rows, about 0.15%, and
never disagree on balance at all. That is a noise band an attacker could
deliberately hide inside, by keeping planted mismatches under the rate the honest
population already shows. I noticed it, and I have not sized anything against it.
Where my attacks need the tape and the servicer to agree they agree exactly, and
where they disagree it is because the trick requires it, not because I was
budgeting against a tolerance.

**Two things I did use, which I do not think are leaks.** In the honest book
`eligible_reported` is true exactly when `dpd_bucket_reported` is 1 or less, in
all 44,628 rows, so the eligibility rule is fully recoverable. I used it, because
it is the credit agreement's own definition and a borrower necessarily knows what
it has agreed its collateral must look like - it is not a property of the bank's
monitoring. Separately, `source_truth` being in the book at all tells me the bank
can tie the tape to the servicer, but `TABLES.md` states that openly as a fact
about the data rather than about the checks.

## Two things worth knowing about the sample book

**The collateral is small relative to the limits.** Across the honest book, the
peak advance a borrower could draw against its own pledged collateral has a
median of 1.7% of its `facility_limit`, and only one borrower reaches 31%. A
gain of 5% of the limit is therefore usually several times the entire honest
collateral book. That is a property of the sample rather than of real lending,
but it shapes everything: an attack that inflates collateral has to create far
more of it than a real borrower would need to, and the planted cohorts here are
large for that reason. If the real books are scaled differently, the collateral
attacks will plant proportionally less.

**On this schema, collateral inflation needs servicer access.** Any attack that
adds pledged assets has to add them to `source_truth` too, because assets on the
tape that the servicing system has never heard of are the most direct tie-out
available. So the four attacks that inflate collateral all set
`USES_SERVICER_RECORDS = True`, and the four that do not touch the tape at all -
`double_pledge`, `round_trip`, `offsheet_shells`, `fee_strip` - all set it False.
The split is deliberate, so that running the test with the lever switched off
tells you something: it should knock out the collateral frauds and leave the cash
and liability frauds untouched. If a borrower cannot write its own servicing
system, the fraud it can still commit is about money and debt, not collateral.
