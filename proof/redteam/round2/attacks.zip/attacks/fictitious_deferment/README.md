# fictitious_deferment

**Story.** Loans that are really 60+ days late, or already charged off, are kept in the borrowing base. From month 5 the tape reports them as current, eligible and "deferred". Charged-off loans, which the honest tape drops, are put back on the tape at their last balance. The borrower runs its own servicing system, so it also rewrites `source_truth` for those loans to say current, which means a records pull under the bank's audit rights agrees with the tape. A single blanket "hardship deferment programme" disclosure is added as the cover story.

**Allegation followed.** DOJ (Tricolor): on recorded calls the CEO proposed blaming loan-data discrepancies on "fictitious deferment policies", while recognising that an auditor asking to "pull this up on your screen" would be a problem. SEC 2026-77: loan metrics manipulated so non-paying or defaulted loans looked current and eligible.

**Levers.** Its own tape and disclosures, plus **the servicer-records lever (`USES_SERVICER_RECORDS = True`)**. Results should be read as the self-servicing case; without the lever `source_truth` would contradict the tape and an audit pull would expose it. I did not build the weaker variant.

**Gain.** `advance_rate x peak monthly balance of truly-bad loans carried as eligible`. This is bounded by how much bad paper the book actually has, so it is not fixed: in the sample book it ranged from about 5% to 18% of `facility_limit` (lowest on borrowers with few bad loans). In a fresh book a borrower with very little bad paper could fall under the 5% floor.

**Why monitoring might miss it.** The tape, the servicer records and the disclosure all tell one story, so only an examiner contacting the borrowers behind a sample of "deferred" loans would find it. Honest weak points: the deferred share jumps at month 5 while the honest loans around them keep paying, so the borrower's payments in `payments` stop for those loans, and deferred loans never return to normal.
