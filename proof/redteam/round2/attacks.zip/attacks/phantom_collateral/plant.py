"""phantom_collateral: wholly fictitious loans on the tape (see README.md)."""
import random
import bookio
from common import borrower_info, max_suffix, fake_vin

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance"]
START_MONTH = 4
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = False

TARGET_FRACTION = 0.17
N_LOANS = 7


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    rng = random.Random(seed)
    b, w = borrower_info(book_dir, borrower_id)
    limit, adv, facility_id = b["facility_limit"], w["advance_rate"], w["facility_id"]

    tape = bookio.load(book_dir, "tape")
    mine = [r for r in tape if r["borrower_id"] == borrower_id]
    if not mine:
        raise ValueError("no tape rows for this borrower")
    pool_rows = [r for r in mine if r["month"] == START_MONTH] or [r for r in mine if r["month"] == min(r2["month"] for r2 in mine)]
    seq = max_suffix([r["asset_id"] for r in mine]) + 1

    per_loan = TARGET_FRACTION * limit / adv / N_LOANS
    new_rows, total0 = [], 0.0
    for i in range(N_LOANS):
        t = rng.choice(pool_rows)                      # a different real loan's profile for each fake loan
        bal0 = per_loan * rng.uniform(0.9, 1.1)
        total0 += bal0
        orig_month = rng.randint(START_MONTH - 8, START_MONTH)
        orig_amount = bal0 * rng.uniform(1.0, 1.06)
        asset_id = f"A-{borrower_id}-{seq + i:06d}"
        obligor_id = f"O-{borrower_id}-{seq + i:06d}"
        vin = fake_vin(rng)
        for m in range(START_MONTH, 24):
            row = dict(t)
            row.update({
                "month": m, "facility_id": facility_id, "borrower_id": borrower_id,
                "asset_id": asset_id, "vin": vin, "obligor_id": obligor_id,
                "balance": float(bal0 * (1 - 0.004 * (m - START_MONTH))),   # slow, plausible amortisation
                "dpd_bucket_reported": 0, "deferred_flag": 0, "eligible_reported": True,
                "orig_month": orig_month, "orig_amount": float(orig_amount),
            })
            new_rows.append(row)
    tape.extend(new_rows)
    bookio.save(book_dir, "tape", tape)

    # the fake loans' balance at their first month, all counted as eligible collateral
    gain = adv * total0
    return {"gain_usd": float(gain),
            "how": f"{N_LOANS} fictitious loans (${total0:,.0f} at month {START_MONTH}) reported current and eligible on {facility_id}; "
                   f"gain = advance rate x fake balance"}
