"""invoice_inflation: real invoices pledged for 60% more than the real amount (see README.md)."""
import random
import bookio
from common import borrower_info

APPLIES_TO = ["receivables_finance"]
START_MONTH = 3
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = False

TARGET_FRACTION = 0.14
MARKUP = 1.6


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    rng = random.Random(seed)
    b, w = borrower_info(book_dir, borrower_id)
    limit, adv = b["facility_limit"], w["advance_rate"]

    paid = {}
    for p in bookio.load(book_dir, "payments"):
        if p["borrower_id"] == borrower_id and p["ref"]:
            paid[p["ref"]] = paid.get(p["ref"], 0.0) + p["amount"]

    invoices = bookio.load(book_dir, "invoices")
    cands = [r for r in invoices if r["borrower_id"] == borrower_id and r["pledged_month"] >= START_MONTH]
    if not cands:
        raise ValueError("no invoices pledged after the start month")
    rng.shuffle(cands)
    target = TARGET_FRACTION * limit
    gain, n = 0.0, 0
    for r in cands:
        if gain >= target:
            break
        P = paid.get(r["invoice_number"], 0.0)           # what the customer really pays
        new = r["amount"] * MARKUP
        # advance on the inflated amount that the bank never gets back, less what an honest pledge would also leave
        g = max(0.0, adv * new - P) - max(0.0, adv * r["amount"] - P)
        r["amount"] = round(new, 2)
        gain += g; n += 1
    bookio.save(book_dir, "invoices", invoices)
    return {"gain_usd": float(gain),
            "how": f"{n} real invoices pledged for {int((MARKUP - 1) * 100)}% more than the customer owes; gain per invoice = "
                   f"advance on the inflated amount minus what the customer actually pays, net of the honest advance"}
