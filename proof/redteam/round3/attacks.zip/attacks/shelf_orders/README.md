# shelf_orders

**Story.** Present fictitious orders and invoices from a controlled shelf company as fresh, arm’s-length customer receivables. A nominee is its public officer; the company falsely shows an established operating history.

**Allegation followed.** allegations/doj-first-brands.txt: alleged invoices for transactions that never occurred. The shelf-company and nominee details are a synthetic extension, not an allegation quoted about that case. All supplied case descriptions are treated as allegations, not established facts. Only the supplied text files were used; their source URLs were not visited.

**Scope and timing.** Applies to receivables_finance; starts at month 6. Derives borrower, facility, asset, customer, and account IDs from the input book. Uses the seed for generated IDs and any random choices. Each invocation is intended for one initially honest borrower, once, on a fresh book.

**Levers.** Add one controlled company and nominee, fake its pre-month-0 formation and operating status, add own invoices, and adjust own financial and existing SEC revenue reports. The undisclosed affiliation is omitted; no third-party public record is rewritten.

Servicer records: **False**. Company history: **True**. Existing customer accomplice: **False**.

**Gain and accounting.** 6% of the facility limit from one batch of nonexistent invoices at month 6, using actual planted face value times the facility advance rate with facility and borrower caps. No payment is invented and no later re-advance is counted.

For collateral scenarios, the supplied book has no bank draw/disbursement ledger or exact underwriting rules. The calculation therefore models a borrower drawing the incremental borrowing capacity at the stated advance rate. It applies both facility limits and the borrower’s aggregate facility_limit. The baseline uses reported eligible loan balances or unpaid pledged invoice balances; it is not a discovered eligibility or detection rule. Gain is a modeled unauthorized advance, not proof the bank actually disbursed it. An unsupported input with insufficient headroom raises an explicit error before saving, rather than inventing gain. All gains are computed from the edits; repeated monthly snapshots are never summed as new proceeds.

**Why monitoring might miss it.** A public register showing an older operating company may make a cursory customer check less informative. Customer confirmations, beneficial ownership work, absent collections, and a field examination can reveal the fiction. The company-history lever is explicitly required.

**Blindness statement.** The design used only README.md, TABLES.md, allegations/, bookio.py, example_attack/, and sample_book/ in the supplied archive. No bank-checking implementation or hidden detection thresholds were found or used. No internet research was performed. The only internet use was the user-authorized installation of pyarrow and numpy. Monitoring effectiveness has not been measured.

**Run.** Put this folder on Python’s module path, import plant, then call `plant.plant(book_dir, borrower_id, seed)`. Requires Python 3.10+, pyarrow, and the included unmodified bookio.py. No other dependencies, network calls, environment-specific paths, or sample borrower IDs are embedded.

**Validation.** Passed 15 offline invocations on independent copies of sample_book/: all 13 applicable sample borrowers with seed 20261002, one alternate-seed test (709) for each supported borrower type, and one exact replay to check determinism. Independently recomputed sample gain: 6.000000%–6.000000% of facility_limit. Tests used the real pyarrow 25.0.1 and supplied bookio.save. They checked schema preservation, no edits to bank history or other borrowers, permitted payer identities, prior customer prefunding, truthful lever flags, no pre-start borrower data changes, unique row identifiers, facility/borrower caps, and the 5% minimum. Original sample parquet hashes remained unchanged. These are input-integrity and accounting tests, not tests of the bank’s monitoring. Fresh unseen books and detection rates are untested.
