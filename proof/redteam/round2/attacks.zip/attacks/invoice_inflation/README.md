# invoice_inflation

**Story.** The borrower leaves its real invoices alone (same numbers, customers and goods) but raises the `amount` on a random set of them by 60% from month 3, so each is pledged for more than the customer owes.

**Allegation followed.** DOJ (First Brands): "the dollar amounts on invoices were altered to make them appear more valuable."

**Levers.** Its own invoice report only (editing the `amount` of its own invoices).

**Gain.** Per invoice: `max(0, adv x inflated - P) - max(0, adv x real - P)`, where `P` is what the customer actually pays in `payments` for that invoice number. A paid invoice leaves about 0.36 x the real amount advanced but never recovered; an unpaid one leaves about 0.51 x. Summed until it reaches 14% of `facility_limit`.

**Why monitoring might miss it.** Invoice counts, debtors, terms and goods are unchanged, so concentration and ageing views look normal. Honest weak point: the customer pays the *real* amount, so any check that compares pledged amount with cash received for the same invoice number sees a persistent short-pay of about 38% (0.6/1.6) on the affected invoices; the same shortfall shows on a debtor confirmation.
