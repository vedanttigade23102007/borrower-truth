# abs_overlap

**Story.** The borrower originates real loans to real customers. They are
properly booked in the servicer, they pay every month, and nothing about them is
false. It then sells them into its own public securitization and reports them to
investors - and pledges the same loans to the bank. Two sets of money are
advanced against one set of cars.

The concealment is a gap in the reporting formats. The ABS-EE report carries no
vehicle identifier, so there is no key on which the bank's tape and the investor
report can be joined. A reader has to match on the nine columns the two reports
share: origination month, amount, rate, term, make, model, model year, obligor
state and credit score. The borrower therefore perturbs two of them in the
investor report - the amount by up to one and a half per cent, the credit score
by a point or two - which is the kind of difference a servicing-system export
legitimately produces, and which defeats an exact match.

**Allegation it follows.** The SEC's Tricolor complaint, which alleges Tricolor
"represented that the loans included in the ABS collateral pools were free and
clear of any other liens when the defendants knew that many had been or would
soon be double pledged", and that more than $945m of ABS principal was
outstanding at bankruptcy.

**Levers.** The loan tape. The servicer system, because the loans are real and
have to exist there. The reports of the borrower's own public securitization.
Payments, because the loans really do pay.

**Gain.** The balance at month 23 of loans that are in the pool and on the tape
at once, multiplied by the advance rate: about 6.5% of `facility_limit`.

**Why monitoring would miss it.** Every check inside the bank's own data passes,
because the loans are genuine. Finding this needs the monitoring to reach for a
different report entirely, notice that it has no join key, and go fuzzy anyway -
matching on the nine shared columns with tolerance on amount and score, and
treating a near-match as a hit rather than a miss. An exact join returns nothing
and looks like a clean result, which is the worst outcome: it is indistinguishable
from the fraud not being there.

A simpler route in is the arithmetic. The pool balance plus the pledged balance
exceeds what the borrower could plausibly have originated, given the pace its own
tape shows in earlier months. Any check that reconciles total originations
against total obligations, rather than matching loan by loan, sees the excess
without needing to identify which loans are doubled.
