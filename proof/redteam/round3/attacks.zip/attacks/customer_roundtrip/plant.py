"""Synthetic offline red-team fixture: customer_roundtrip. See README.md for gain assumptions."""
APPLIES_TO = ['receivables_finance']
START_MONTH = 6
USES_SERVICER_RECORDS = False
USES_COMPANY_HISTORY = False
USES_CUSTOMER_ACCOMPLICE = True
ATTACK = 'customer_roundtrip'

import hashlib
import math
import random
from collections import defaultdict
import bookio


class Context:
    def __init__(self, book_dir, borrower_id, seed):
        self.path, self.bid = book_dir, borrower_id
        self.tables, self.dirty = {}, set()
        self.b = next(x for x in self.rows('borrowers') if x['borrower_id'] == borrower_id)
        if self.b['btype'] not in APPLIES_TO:
            raise ValueError('Borrower type is outside APPLIES_TO')
        self.limit = float(self.b['facility_limit'])
        self.facilities = {x['facility_id']: x for x in self.rows('facilities') if x['borrower_id'] == borrower_id}
        self.rng = random.Random(seed)
        self.prefix = hashlib.sha256(f'{ATTACK}|{borrower_id}|{seed}'.encode()).hexdigest()[:14]
        self.serial = 0

    def rows(self, table):
        if table not in self.tables:
            self.tables[table] = bookio.load(self.path, table)
        return self.tables[table]

    def own(self, table):
        return [x for x in self.rows(table) if x.get('borrower_id') == self.bid]

    def uid(self, kind):
        self.serial += 1
        return f'{kind}-{self.bid}-{self.prefix}-{self.serial:05d}'

    def save(self):
        for t in sorted(self.dirty):
            bookio.save(self.path, t, self.tables[t])

    def baseline(self, month):
        # This is a collateral-value accounting proxy, not a bank detector.
        face = defaultdict(float)
        if self.b['btype'] == 'receivables_finance':
            paid = defaultdict(float)
            for p in self.own('payments'):
                if p['month'] <= month:
                    paid[p['ref']] += p['amount']
            for i in self.own('invoices'):
                if i['pledged_month'] <= month:
                    face[i['facility_id']] += max(0.0, i['amount'] - paid[i['invoice_number']])
        else:
            for a in self.own('tape'):
                if a['month'] == month and a['eligible_reported']:
                    face[a['facility_id']] += a['balance']
        return {fid: face[fid] * f['advance_rate'] for fid, f in self.facilities.items()}

    def delta(self, baseline, added):
        before = min(self.limit, sum(min(f['limit'], baseline[fid]) for fid, f in self.facilities.items()))
        after = min(self.limit, sum(min(f['limit'], baseline[fid] + added.get(fid, 0.0)) for fid, f in self.facilities.items()))
        return max(0.0, after - before)

    def facility(self, target, candidates=None):
        baseline = self.baseline(START_MONTH)
        options = [f for fid, f in self.facilities.items() if f['advance_rate'] > 0 and (candidates is None or fid in candidates)]
        options.sort(key=lambda f: (f['kind'] != 'warehouse', -f['limit'], f['facility_id']))
        for f in options:
            if self.delta(baseline, {f['facility_id']: target}) >= target - 0.01:
                return f, baseline
        raise ValueError('Insufficient collateral-based headroom for the requested gain; no gain fabricated')

    def accounts(self):
        incoming = self.own('payments')
        outgoing = self.own('outflows')
        if not incoming or not outgoing:
            raise ValueError('Need existing collection and operating accounts')
        return incoming[0]['account_id'], outgoing[0]['account_id']

    def financials(self, receivable_by_month=None, cash=0.0, debt=0.0, revenue=0.0):
        for q in self.own('financials'):
            month = 3*q['quarter'] + 2
            if month < START_MONTH:
                continue
            q['receivables_reported'] += (receivable_by_month or {}).get(month, 0.0)
            q['cash_reported'] += cash
            q['debt_reported'] += debt
            if q['quarter'] == START_MONTH // 3:
                q['revenue_reported'] += revenue
        self.dirty.add('financials')
        if revenue:
            for r in self.own('sec_filings'):
                if r['filed_month'] >= START_MONTH and r['item'] == 'revenue' and r['quarter'] == START_MONTH // 3 and r['amount'] is not None:
                    r['amount'] += revenue
                    self.dirty.add('sec_filings')

    def company(self, shelf=False):
        eid, pid = self.uid('E'), self.uid('P')
        # The new nominee is under the attack's control; do not edit other persons.
        self.rows('persons').append({'person_id': pid, 'name': f'Synthetic Nominee {self.prefix[:6]}'})
        e = {'entity_id': eid, 'name': f'Synthetic {self.prefix[:6]} Distribution LLC',
             'kind': 'company', 'officer_person_id': pid,
             'address': f'{self.rng.randrange(100, 9900)} Example Commerce Way',
             'state': self.b['state'], 'phone': f'555-010-{self.rng.randrange(1000, 10000)}',
             'registered_agent': 'Synthetic Independent Registry Services',
             'formed_month': -60 if shelf else START_MONTH,
             'has_operations': bool(shelf)}
        self.rows('entities').append(e)
        self.dirty.update(['entities', 'persons'])
        return e

    def result(self, gain, how):
        if not math.isfinite(gain) or gain < 0.05*self.limit - 0.01:
            raise ValueError('Computed gain fails the 5% rule')
        self.save()
        return {'gain_usd': float(gain), 'how': how}


def split_amount(total, count):
    cents = round(total*100)
    q, r = divmod(cents, count)
    return [(q + (j < r))/100 for j in range(count)]

def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    c = Context(book_dir, borrower_id, seed)
    f, baseline = c.facility(0.07*c.limit)
    templates = sorted([i for i in c.own('invoices') if i['pledged_month'] < START_MONTH], key=lambda i:i['invoice_id'])
    if not templates:
        raise ValueError('No pre-existing invoice customer')
    template = c.rng.choice(templates)
    coll, oper = c.accounts()
    support = round(0.01*c.limit,2)
    residual = math.ceil(0.07*c.limit/f['advance_rate']*100)/100
    face = residual + support
    for amount, subsidy in zip(split_amount(face,4), split_amount(support,4)):
        i = dict(template)
        i.update(invoice_id=c.uid('INV'), invoice_number=c.uid('BILL'), po_number=c.uid('PO'),
                 facility_id=f['facility_id'], pledged_month=START_MONTH,
                 issue_month=START_MONTH, issue_day=1, due_days=60, amount=amount)
        c.rows('invoices').append(i)
        c.rows('outflows').append({'txn_id':c.uid('O'), 'month':START_MONTH, 'day':4,
            'borrower_id':borrower_id, 'account_id':oper,
            'payee_id':template['debtor_id'], 'payee_name':template['debtor_name'],
            'amount':subsidy, 'memo':'customer commercial allowance'})
        c.rows('payments').append({'txn_id':c.uid('T'), 'month':START_MONTH, 'day':8,
            'borrower_id':borrower_id, 'account_id':coll,
            'payer_id':template['debtor_id'], 'payer_name':template['debtor_name'],
            'amount':subsidy, 'memo':'invoice payment', 'ref':i['invoice_number']})
    c.dirty.update(['invoices','outflows','payments'])
    gross = c.delta(baseline, {f['facility_id']:residual*f['advance_rate']})
    gain = gross-support
    c.financials({m:residual for m in range(START_MONTH,24)}, cash=gain, debt=gross, revenue=face)
    return c.result(gain, 'Capped advance on unpaid fake invoice residual, less all customer-prefunding outflows')
