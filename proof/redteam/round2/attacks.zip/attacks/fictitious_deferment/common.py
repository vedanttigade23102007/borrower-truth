"""Small helpers shared by the attacks (copied into each attack folder)."""
import bookio


def borrower_info(book_dir, borrower_id):
    b = next(x for x in bookio.load(book_dir, "borrowers") if x["borrower_id"] == borrower_id)
    fac = [f for f in bookio.load(book_dir, "facilities") if f["borrower_id"] == borrower_id]
    w = next((f for f in fac if f["kind"] == "warehouse"), fac[0])
    return b, w


def max_suffix(ids):
    """Largest trailing number in ids like 'A-B0001-000110' (0 if none)."""
    best = 0
    for i in ids:
        tail = i.rsplit("-", 1)[-1]
        if tail.isdigit():
            best = max(best, int(tail))
    return best


def fake_vin(rng):
    return "SYN" + "".join(rng.choice("0123456789ABCDEFGHJKLMNPRSTUVWXYZ") for _ in range(14))
