# fee_strip

**Story.** Nothing is wrong with the collateral. The loans are real, the tape is
honest, the servicer agrees, the registry is clean, the covenant is met. The
borrower is being emptied out through its operating account instead.

The owner sets up two companies and signs the borrower to a servicing and
premises agreement priced far above the market. From month 5 money leaves every
month as ordinary vendor payments and rent, split unevenly between the two
payees and varied month to month so it never looks like a standing order. By the
time the facility is in trouble the cash has gone and the bank's recovery is
against an empty company.

Two details do the hiding. One of the two companies is disclosed as a related
party - but the note describes it as a back-office servicing vendor, which makes
the relationship look administrative rather than extractive, and the other
company is not disclosed at all. And the officer named on the register for each
is a nominee, so a search starting from the borrower's owner does not reach
either of them.

**Allegation it follows.** None directly, though it sits beside the IRS-CI
characterisation of First Brands as a scheme in which new loan proceeds were used
"to pay back old lenders and to fund their extravagant lifestyle". The mechanism
here is ordinary asset-stripping ahead of a default rather than collateral fraud.

**Levers.** New companies and people, one of them an aged company shown as
having operations. Disclosures. Outflows from the operating account. No servicer
access, no change to the tape, no change to the financial statements.

**Gain.** Everything extracted above what the service is worth - and since the
arrangement is a pretext, that is the whole of it. About 6.5% of
`facility_limit` over nineteen months.

**Why monitoring would miss it.** Every check that looks at collateral finds a
clean book, and this borrower will look like one of the better names in the
portfolio right up to the point it fails. A monitoring programme built around
the borrowing base has no instrument pointed at this at all.

What finds it is reading the operating account as a profile rather than a total.
Two payees appear at the same time and immediately take a large and growing share
of everything the company spends; one of them is disclosed under a description
that understates the relationship and the other is not disclosed; both are
officered by people who appear nowhere else in the registry; and the combined
monthly amount grows while payroll and the rest of the cost base do not. The
single most useful question is the plainest one: is this borrower spending more
on servicing than a company of its size could possibly need, and who is on the
other end.

**Without the company-history lever** the aged, operating-looking vehicle becomes
a company formed during the facility with no operations, which is a much poorer
disguise for an entity receiving several per cent of the facility limit.
