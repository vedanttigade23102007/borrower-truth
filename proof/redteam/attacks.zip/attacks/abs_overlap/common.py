"""Helpers shared by the attack scripts.

A copy of this file sits in every attack folder, so each plant.py can
``import common`` without depending on anything outside its own directory.
Standard library + pyarrow (via bookio) + numpy only.
"""
import math
import random

import bookio

MONTHS = 24
LAST_MONTH = 23

# Sort keys the honest book already satisfies; planted rows are merged in so the
# table still looks native.
SORT_KEYS = {
    "tape": ("borrower_id", "month", "asset_id"),
    "source_truth": ("borrower_id", "month", "asset_id"),
    "payments": ("txn_id",),
    "outflows": ("txn_id",),
    "invoices": ("invoice_id",),
}


def save(book_dir, table, rows):
    key = SORT_KEYS.get(table)
    if key:
        rows = sorted(rows, key=lambda r: tuple(r[c] for c in key))
    bookio.save(book_dir, table, rows)


# ---------------------------------------------------------------- context


class Ctx:
    """Everything an attack needs to know about one borrower."""

    def __init__(self, book_dir, borrower_id, seed):
        self.dir = book_dir
        self.bid = borrower_id
        self.rng = random.Random(seed ^ (hash(borrower_id) & 0xFFFFFFF))
        self.borrower = next(
            b for b in bookio.load(book_dir, "borrowers") if b["borrower_id"] == borrower_id
        )
        self.limit = float(self.borrower["facility_limit"])
        self.btype = self.borrower["btype"]
        self.entity_id = self.borrower["entity_id"]
        self.owner = self.borrower["owner_person_id"]
        self.state = self.borrower["state"]
        facs = [f for f in bookio.load(book_dir, "facilities") if f["borrower_id"] == borrower_id]
        self.facility = next((f for f in facs if f["kind"] == "warehouse"), facs[0])
        self.fid = self.facility["facility_id"]
        self.advance_rate = float(self.facility["advance_rate"])
        self.coll_account = f"{self.fid}-COLL"
        self.oper_account = f"{self.fid}-OPER"

    def target(self, pct=0.065):
        """Dollar gain to aim for. The floor is 5% of the limit; we aim a little
        above so sampling noise across books cannot push a run under."""
        return self.limit * pct


# ---------------------------------------------------------------- id minting


def _max_suffix(rows, col, prefix_len):
    best = 0
    for r in rows:
        v = r[col]
        if not isinstance(v, str) or len(v) <= prefix_len:
            continue
        tail = v[prefix_len:]
        if tail.isdigit():
            best = max(best, int(tail))
    return best


def txn_minter(book_dir, table):
    """Continue the book's own T000000000 / O000000000 numbering."""
    rows = bookio.load(book_dir, table)
    letter = "T" if table == "payments" else "O"
    n = _max_suffix(rows, "txn_id", 1)
    counter = [n]

    def mint():
        counter[0] += 1
        return f"{letter}{counter[0]:09d}"

    return mint


def entity_minter(entities):
    n = _max_suffix(entities, "entity_id", 1)
    counter = [n]

    def mint():
        counter[0] += 1
        return f"E{counter[0]:06d}"

    return mint


def person_minter(persons):
    n = _max_suffix(persons, "person_id", 1)
    counter = [n]

    def mint():
        counter[0] += 1
        return f"P{counter[0]:05d}"

    return mint


def invoice_minter(invoices):
    n = _max_suffix(invoices, "invoice_id", 3)
    counter = [n]

    def mint():
        counter[0] += 1
        return f"INV{counter[0]:08d}"

    return mint


def asset_minter(ctx, tape):
    """New asset ids continue the borrower's own A-<bid>-NNNNNN series."""
    pre = f"A-{ctx.bid}-"
    n = max(
        [int(r["asset_id"][len(pre):]) for r in tape
         if r["borrower_id"] == ctx.bid and r["asset_id"].startswith(pre)
         and r["asset_id"][len(pre):].isdigit()] or [0]
    )
    counter = [n]

    def mint():
        counter[0] += 1
        return (f"{pre}{counter[0]:06d}", f"O-{ctx.bid}-{counter[0]:06d}")

    return mint


VIN_CHARS = "ABCDEFGHJKLMNPRSTUVWXYZ0123456789"


def make_vin(rng):
    return "SYN" + "".join(rng.choice(VIN_CHARS) for _ in range(14))


# ---------------------------------------------------------------- name shop

FIRST = ["James", "Maria", "Robert", "Linda", "Michael", "Patricia", "David", "Jennifer",
         "William", "Elizabeth", "Richard", "Susan", "Joseph", "Jessica", "Thomas", "Sarah",
         "Charles", "Karen", "Daniel", "Nancy", "Matthew", "Lisa", "Anthony", "Betty"]
LAST = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
        "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
        "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White"]
CO_A = ["Summit", "Beacon", "Cardinal", "Meridian", "Lakeside", "Ironbridge", "Westbrook",
        "Clearwater", "Redstone", "Fairmount", "Oakline", "Brightwater", "Stonegate",
        "Riverbend", "Highpoint", "Crestview", "Ambler", "Northgate"]
CO_B = ["Holdings", "Capital", "Partners", "Group", "Ventures", "Enterprises", "Associates",
        "Industries", "Trading", "Supply", "Distribution", "Logistics"]
CO_C = ["LLC", "Inc", "LP", "Corp"]
STREET = ["Center Dr", "Main St", "Park Ave", "Commerce Way", "Industrial Pkwy", "Market St",
          "Harbor Blvd", "Lincoln Ave", "Franklin Rd", "Union St"]
AGENTS = ["(synthetic) Registered Agent Services LLC, 12 Filing Way",
          "(synthetic) Corporate Agents Inc, 100 Registry Plaza",
          "(synthetic) National Agent Co, 7 Statehouse Sq"]


def person_name(rng):
    return f"{rng.choice(FIRST)} {rng.choice(LAST)}"


def company_name(rng):
    return f"{rng.choice(CO_A)} {rng.choice(CO_B)} {rng.choice(CO_C)}"


def address(rng):
    return f"{rng.randint(100, 9999)} {rng.choice(STREET)}, Suite {rng.randint(1, 900)}"


def phone(rng):
    return f"555-{rng.randint(100, 999)}-{rng.randint(1000, 9999)}"


def new_entity(rng, eid, name, kind, officer, state, formed_month, has_operations,
               addr=None, ph=None, agent=None):
    return {
        "entity_id": eid,
        "name": name,
        "kind": kind,
        "officer_person_id": officer,
        "address": addr if addr is not None else address(rng),
        "state": state,
        "formed_month": int(formed_month),
        "has_operations": bool(has_operations),
        "phone": ph if ph is not None else phone(rng),
        "registered_agent": agent if agent is not None else rng.choice(AGENTS),
    }


# ---------------------------------------------------------------- loan maths


def loan_profile(ctx, tape_rows):
    """Characteristics of the borrower's real loans, so fakes sit inside them."""
    mine = [r for r in tape_rows if r["borrower_id"] == ctx.bid]
    originals = {}
    for r in mine:
        originals.setdefault(r["asset_id"], r)
    sample = list(originals.values())
    amounts = sorted(r["orig_amount"] for r in sample)
    return {
        "sample": sample,
        "p20": amounts[int(len(amounts) * 0.20)] if amounts else 10000.0,
        "p80": amounts[int(len(amounts) * 0.80)] if amounts else 30000.0,
        "median": amounts[len(amounts) // 2] if amounts else 20000.0,
    }


def draw_loan(ctx, prof, orig_month):
    """One plausible new loan for this borrower, cloned from a real one."""
    rng = ctx.rng
    base = rng.choice(prof["sample"])
    amt = round(rng.uniform(prof["p20"], prof["p80"]) * rng.uniform(0.92, 1.08), 2)
    return {
        "orig_amount": amt,
        "rate": base["rate"],
        "term": int(base["term"]),
        "make": base["make"],
        "model": base["model"],
        "model_year": int(base["model_year"]),
        "obligor_state": base["obligor_state"],
        "credit_score": int(min(850, max(300, base["credit_score"] + rng.randint(-25, 25)))),
        "orig_month": int(orig_month),
        "vin": make_vin(rng) if base["vin"] else "",
    }


def balance_at(loan, month):
    """Straight-line-ish amortisation; 0 once the term is done."""
    term = loan["term"] or 60
    age = month - loan["orig_month"]
    if age < 0:
        return None
    if age >= term:
        return 0.0
    return float(loan["orig_amount"]) * (1.0 - age / float(term))


def monthly_payment(loan):
    term = loan["term"] or 60
    return float(loan["orig_amount"]) / term


def tape_row(ctx, asset_id, obligor_id, loan, month, bal, dpd=0, deferred=0, eligible=True):
    return {
        "month": int(month),
        "facility_id": ctx.fid,
        "borrower_id": ctx.bid,
        "asset_id": asset_id,
        "vin": loan["vin"],
        "obligor_id": obligor_id,
        "balance": float(bal),
        "dpd_bucket_reported": int(dpd),
        "deferred_flag": int(deferred),
        "eligible_reported": bool(eligible),
        "orig_month": int(loan["orig_month"]),
        "orig_amount": float(loan["orig_amount"]),
        "rate": loan["rate"],
        "term": int(loan["term"]),
        "make": loan["make"],
        "model": loan["model"],
        "model_year": int(loan["model_year"]),
        "obligor_state": loan["obligor_state"],
        "credit_score": int(loan["credit_score"]),
    }


def truth_row(ctx, asset_id, month, dpd, bal):
    return {
        "month": int(month),
        "borrower_id": ctx.bid,
        "asset_id": asset_id,
        "dpd_bucket_true": int(dpd),
        "balance_true": float(bal),
    }


def payment_row(ctx, txn_id, month, day, payer_id, payer_name, amount, memo, ref,
                account=None):
    return {
        "txn_id": txn_id,
        "month": int(month),
        "day": int(day),
        "borrower_id": ctx.bid,
        "account_id": account or ctx.coll_account,
        "payer_id": payer_id,
        "payer_name": payer_name,
        "amount": round(float(amount), 2),
        "memo": memo,
        "ref": ref,
    }


def outflow_row(ctx, txn_id, month, day, payee_id, payee_name, amount, memo):
    return {
        "txn_id": txn_id,
        "month": int(month),
        "day": int(day),
        "borrower_id": ctx.bid,
        "account_id": ctx.oper_account,
        "payee_id": payee_id,
        "payee_name": payee_name,
        "amount": round(float(amount), 2),
        "memo": memo,
    }


def ramp(start_month, end_month=LAST_MONTH):
    """Months the fraud acts on, inclusive."""
    return list(range(max(0, int(start_month)), end_month + 1))


def smooth_share(i, n):
    """0..1 S-curve so a planted cohort grows in rather than appearing at once."""
    if n <= 1:
        return 1.0
    x = i / float(n - 1)
    return 0.5 - 0.5 * math.cos(math.pi * x)
