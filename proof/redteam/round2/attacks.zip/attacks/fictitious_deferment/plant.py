"""fictitious_deferment: genuinely bad loans kept on the books as 'deferred', with the servicer system edited to agree."""
import bookio
from common import borrower_info

APPLIES_TO = ["auto_finance", "consumer_finance", "real_estate_finance"]
START_MONTH = 5
USES_SERVICER_RECORDS = True
USES_COMPANY_HISTORY = False


def plant(book_dir: str, borrower_id: str, seed: int) -> dict:
    b, w = borrower_info(book_dir, borrower_id)
    adv = w["advance_rate"]

    st = bookio.load(book_dir, "source_truth")
    tape = bookio.load(book_dir, "tape")
    st_idx = {(r["asset_id"], r["month"]): r for r in st if r["borrower_id"] == borrower_id}
    tp_idx = {(r["asset_id"], r["month"]): r for r in tape if r["borrower_id"] == borrower_id}
    last_tape = {}
    for r in sorted((r for r in tape if r["borrower_id"] == borrower_id), key=lambda r: r["month"]):
        last_tape[r["asset_id"]] = r
    assets = sorted({a for (a, m) in st_idx})

    carried = {m: 0.0 for m in range(24)}      # balance of truly-bad loans kept as eligible, per month
    new_tape, new_st = [], []
    n_loans = 0
    for a in assets:
        co_month, co_bal = None, None
        touched = False
        for m in range(START_MONTH, 24):
            s = st_idx.get((a, m))
            if co_month is None and s is not None and s["dpd_bucket_true"] == 4:
                co_month, co_bal = m, float(s["balance_true"])
            bad = (s is not None and s["dpd_bucket_true"] >= 2) or co_month is not None
            if not bad:
                continue
            t = tp_idx.get((a, m))
            if t is not None:
                bal = float(t["balance"])
                t["dpd_bucket_reported"] = 0; t["deferred_flag"] = 1; t["eligible_reported"] = True
            elif co_month is not None and a in last_tape:
                bal = co_bal
                row = dict(last_tape[a])
                row.update({"month": m, "balance": co_bal, "dpd_bucket_reported": 0, "deferred_flag": 1, "eligible_reported": True})
                new_tape.append(row)
            else:
                continue
            carried[m] += bal
            touched = True
            if s is not None:
                s["dpd_bucket_true"] = 0           # the self-run servicer system is edited to match the tape
            elif co_month is not None:
                new_st.append({"month": m, "borrower_id": borrower_id, "asset_id": a, "dpd_bucket_true": 0, "balance_true": co_bal})
        n_loans += touched
    if n_loans == 0:
        raise ValueError("no genuinely bad loans to defer in this book")
    tape.extend(new_tape); st.extend(new_st)
    bookio.save(book_dir, "tape", tape)
    bookio.save(book_dir, "source_truth", st)

    disc = bookio.load(book_dir, "disclosures")
    if not any(d["borrower_id"] == borrower_id and d["kind"] == "deferment_program" for d in disc):
        disc.append({"borrower_id": borrower_id, "kind": "deferment_program", "counterparty_entity_id": None,
                     "start_month": START_MONTH, "note": "hardship deferment program for affected customers"})
        bookio.save(book_dir, "disclosures", disc)

    peak = max(carried.values())
    return {"gain_usd": float(adv * peak),
            "how": f"{n_loans} loans that are really 60+ days late or charged off kept on the tape as current, eligible and deferred "
                   f"(peak ${peak:,.0f}); source_truth edited to match; gain = advance rate x peak balance of loans that should be ineligible"}
