# double_pledge

**Story.** From month 8 the borrower raises a second facility from another
lender in the registry, secured on the same loans it has already pledged to the
bank. It draws the line down in a handful of tranches across the window. The
bank's collateral is now financing two debts, and in a default the bank is
competing for it.

Three things keep it quiet. The borrower stops being enrolled in the shared
collateral registry, which the rules permit by removing its own rows, so the
duplicate pledge is never tested. The second lender is never named in a
disclosure and the quarterly debt figure is left on its honest trend. And the
interest, which does have to be paid, leaves the operating account as ordinary
vendor payments to a newly formed servicing company rather than as debt service
to a lender.

Nothing is added to the tape and nothing is touched in the servicer. The
collateral record is entirely truthful. The fraud is a liability the bank cannot
see.

**Allegation it follows.** Tricolor, where double-pledging to multiple lenders
is the central charge, and First Brands, where assets "purported to be
unencumbered ... in fact [were] already subject to liens by, or otherwise
pledged to, First Brands' senior lenders".

**Levers.** PledgeCheck enrolment, by removing the borrower's own rows. A new
company, formed during the facility and showing no operations, as the payment
conduit. Outflows from the operating account. No servicer access, no faked
company history, no change to the tape.

**Gain.** The principal outstanding on the hidden facility at the end of the
window: about 6.5% of `facility_limit`. This is the README's third category -
debt taken elsewhere and hidden from the bank.

**Why monitoring would miss it.** There is nothing wrong with the collateral, so
collateral checks find nothing. There is no new lien filing, because the second
lender was content to go unperfected or filed somewhere the search did not
reach, and lien filings are outside the borrower's control in either direction.
The registry is silent because the borrower is no longer in it - and silence
there is ordinary, since fifteen of the thirty-four honest borrowers in the
sample book are not enrolled either.

The one durable trace is the money. A new payee appears in the operating account
in month 8 and is paid every month thereafter, in amounts that rise in steps and
then drift with the balance, which is what an interest schedule looks like
however it is labelled. The payee is a company formed weeks earlier with no
operations. Monitoring that reads outflows as a stream of counterparties with
histories, rather than as a sum by memo category, has a real chance here.
Monitoring that treats de-enrolment from the registry as an event rather than as
missing data has another.
